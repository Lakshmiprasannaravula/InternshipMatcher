import { InternshipManagementPage } from "@/components/admin-pages";

export default function AdminInternshipsPage() {
  return <InternshipManagementPage />;
}
