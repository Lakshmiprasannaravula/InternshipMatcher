import { CandidateManagementPage } from "@/components/admin-pages";

export default function AdminCandidatesPage() {
  return <CandidateManagementPage />;
}
