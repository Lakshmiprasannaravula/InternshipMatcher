import { AdminLoginPage } from "@/components/auth-pages";

export default function AdminLogin() {
  return <AdminLoginPage />;
}
