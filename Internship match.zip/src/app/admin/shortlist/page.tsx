import { ShortlistManagementPage } from "@/components/admin-pages";

export default function AdminShortlistPage() {
  return <ShortlistManagementPage />;
}
