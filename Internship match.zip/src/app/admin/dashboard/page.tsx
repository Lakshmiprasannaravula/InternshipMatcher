import { AdminDashboard } from "@/components/admin-pages";

export default function AdminDashboardPage() {
  return <AdminDashboard />;
}
