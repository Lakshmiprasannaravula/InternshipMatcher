import { SkillGapPage } from "@/components/student-pages";

export default function SkillGapsPage() {
  return <SkillGapPage />;
}
