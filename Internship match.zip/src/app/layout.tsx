import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { DemoProvider } from "@/lib/demo-store";

export const metadata: Metadata = {
  title: "InternMatch AI — Find the opportunity that fits you",
  description: "An intelligent internship matching platform connecting student skills, interests, projects and achievements to meaningful opportunities.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <DemoProvider>{children}</DemoProvider>
      </body>
    </html>
  );
}
