import { LogoutPage } from "@/components/logout-page";

export default function LogoutRoute() {
  return <LogoutPage />;
}
