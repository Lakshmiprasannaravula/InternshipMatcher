import { CareerRoadmapPage } from "@/components/student-pages";

export default function RoadmapPage() {
  return <CareerRoadmapPage />;
}
