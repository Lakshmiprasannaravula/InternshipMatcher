import { ChatbotPage } from "@/components/chatbot";

export default function ChatbotRoute() {
  return <ChatbotPage />;
}
