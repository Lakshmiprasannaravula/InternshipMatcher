import { AchievementsPage } from "@/components/student-pages";

export default function AchievementsPortfolioPage() {
  return <AchievementsPage />;
}
