import { InternshipDetailsPage } from "@/components/student-pages";

type InternshipRouteProps = {
  params: Promise<{ id: string }>;
};

export default async function InternshipPage({ params }: InternshipRouteProps) {
  const { id } = await params;
  return <InternshipDetailsPage id={id} />;
}
