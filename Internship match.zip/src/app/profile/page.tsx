import { StudentProfilePage } from "@/components/student-pages";

export default function ProfilePage() {
  return <StudentProfilePage />;
}
