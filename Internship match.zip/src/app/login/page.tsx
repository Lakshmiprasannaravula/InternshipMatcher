import { StudentLoginPage } from "@/components/auth-pages";

export default function LoginPage() {
  return <StudentLoginPage />;
}
