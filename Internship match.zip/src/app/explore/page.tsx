import { ExplorePage } from "@/components/student-pages";

export default function ExploreInternshipsPage() {
  return <ExplorePage />;
}
