import { ResumeAnalyzerPage } from "@/components/student-pages";

export default function ResumePage() {
  return <ResumeAnalyzerPage />;
}
