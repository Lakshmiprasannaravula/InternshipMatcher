import { MatchesPage } from "@/components/student-pages";

export default function MatchAnalysisPage() {
  return <MatchesPage />;
}
