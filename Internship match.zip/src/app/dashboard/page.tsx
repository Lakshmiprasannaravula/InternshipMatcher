import { StudentDashboard } from "@/components/student-pages";

export default function DashboardPage() {
  return <StudentDashboard />;
}
