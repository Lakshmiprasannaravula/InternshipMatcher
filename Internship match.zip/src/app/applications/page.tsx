import { ApplicationsPage } from "@/components/student-pages";

export default function ApplicationsTrackerPage() {
  return <ApplicationsPage />;
}
