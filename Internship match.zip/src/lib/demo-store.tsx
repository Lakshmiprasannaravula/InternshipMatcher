"use client";

import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import {
  defaultProfile,
  initialAchievements,
  initialInternships,
  type Achievement,
  type Application,
  type ApplicationStatus,
  type Internship,
  type Profile,
  type Project,
} from "@/lib/data";

const STORAGE_KEY = "internmatch-ai-demo-v1";

type DemoState = {
  profile: Profile;
  internships: Internship[];
  applications: Application[];
  savedInternships: string[];
  achievements: Achievement[];
  shortlistedCandidates: string[];
  completedRoadmapSteps: string[];
  learningGoals: string[];
  role: "student" | "admin" | null;
};

const initialState: DemoState = {
  profile: defaultProfile,
  internships: initialInternships,
  applications: [
    { id: "app-1", internshipId: "data-analyst", status: "In review", appliedAt: "2026-02-14" },
    { id: "app-2", internshipId: "ai-research", status: "Interview", appliedAt: "2026-02-12" },
  ],
  savedInternships: ["frontend-engineer", "ux-design"],
  achievements: initialAchievements,
  shortlistedCandidates: ["cand-1", "cand-3"],
  completedRoadmapSteps: ["profile", "resume"],
  learningGoals: [],
  role: null,
};

type DemoContextValue = {
  state: DemoState;
  hydrated: boolean;
  updateProfile: (changes: Partial<Profile>) => void;
  toggleSaved: (internshipId: string) => void;
  applyToInternship: (internshipId: string) => boolean;
  updateApplicationStatus: (applicationId: string, status: ApplicationStatus) => void;
  removeApplication: (applicationId: string) => void;
  addLearningGoal: (skill: string) => void;
  addProject: (project: Omit<Project, "id">) => void;
  removeProject: (projectId: string) => void;
  addAchievement: (achievement: Omit<Achievement, "id">) => void;
  toggleRoadmapStep: (stepId: string) => void;
  toggleCandidateShortlist: (candidateId: string) => void;
  addInternship: (internship: Omit<Internship, "id">) => void;
  updateInternship: (internshipId: string, changes: Partial<Omit<Internship, "id">>) => void;
  removeInternship: (internshipId: string) => void;
  signIn: (role: "student" | "admin", name?: string, email?: string) => void;
  signOut: () => void;
};

const DemoContext = createContext<DemoContextValue | null>(null);

export function DemoProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<DemoState>(initialState);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as Partial<DemoState>;
        setState({ ...initialState, ...parsed });
      }
    } catch {
      window.localStorage.removeItem(STORAGE_KEY);
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // The demo remains usable when browser storage is unavailable or full.
    }
  }, [hydrated, state]);

  const value = useMemo<DemoContextValue>(() => ({
    state,
    hydrated,
    updateProfile: (changes) => setState((current) => ({
      ...current,
      profile: { ...current.profile, ...changes },
    })),
    toggleSaved: (internshipId) => setState((current) => ({
      ...current,
      savedInternships: current.savedInternships.includes(internshipId)
        ? current.savedInternships.filter((id) => id !== internshipId)
        : [...current.savedInternships, internshipId],
    })),
    applyToInternship: (internshipId) => {
      if (state.applications.some((application) => application.internshipId === internshipId)) return false;
      setState((current) => current.applications.some((application) => application.internshipId === internshipId)
        ? current
        : {
          ...current,
          applications: [
            { id: `app-${Date.now()}`, internshipId, status: "Applied", appliedAt: new Date().toISOString().slice(0, 10) },
            ...current.applications,
          ],
        });
      return true;
    },
    updateApplicationStatus: (applicationId, status) => setState((current) => ({
      ...current,
      applications: current.applications.map((application) =>
        application.id === applicationId ? { ...application, status } : application,
      ),
    })),
    removeApplication: (applicationId) => setState((current) => ({
      ...current,
      applications: current.applications.filter((application) => application.id !== applicationId),
    })),
    addLearningGoal: (skill) => setState((current) => ({
      ...current,
      learningGoals: current.learningGoals.includes(skill) ? current.learningGoals : [...current.learningGoals, skill],
    })),
    addProject: (project) => setState((current) => ({
      ...current,
      profile: { ...current.profile, projects: [{ ...project, id: `project-${Date.now()}` }, ...current.profile.projects] },
    })),
    removeProject: (projectId) => setState((current) => ({
      ...current,
      profile: { ...current.profile, projects: current.profile.projects.filter((project) => project.id !== projectId) },
    })),
    addAchievement: (achievement) => setState((current) => ({
      ...current,
      achievements: [{ ...achievement, id: `achievement-${Date.now()}` }, ...current.achievements],
    })),
    toggleRoadmapStep: (stepId) => setState((current) => ({
      ...current,
      completedRoadmapSteps: current.completedRoadmapSteps.includes(stepId)
        ? current.completedRoadmapSteps.filter((id) => id !== stepId)
        : [...current.completedRoadmapSteps, stepId],
    })),
    toggleCandidateShortlist: (candidateId) => setState((current) => ({
      ...current,
      shortlistedCandidates: current.shortlistedCandidates.includes(candidateId)
        ? current.shortlistedCandidates.filter((id) => id !== candidateId)
        : [...current.shortlistedCandidates, candidateId],
    })),
    addInternship: (internship) => setState((current) => {
      const slug = internship.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
      const id = `${slug || "opportunity"}-${Date.now().toString().slice(-5)}`;
      return { ...current, internships: [{ ...internship, id }, ...current.internships] };
    }),
    updateInternship: (internshipId, changes) => setState((current) => ({
      ...current,
      internships: current.internships.map((internship) => internship.id === internshipId ? { ...internship, ...changes } : internship),
    })),
    removeInternship: (internshipId) => setState((current) => ({
      ...current,
      internships: current.internships.filter((internship) => internship.id !== internshipId),
    })),
    signIn: (role, name, email) => setState((current) => ({
      ...current,
      role,
      profile: role === "student" ? {
        ...current.profile,
        ...(name ? { name } : {}),
        ...(email ? { email } : {}),
      } : current.profile,
    })),
    signOut: () => setState((current) => ({ ...current, role: null })),
  }), [hydrated, state]);

  return <DemoContext.Provider value={value}>{children}</DemoContext.Provider>;
}

export function useDemo() {
  const context = useContext(DemoContext);
  if (!context) throw new Error("useDemo must be used inside DemoProvider");
  return context;
}
