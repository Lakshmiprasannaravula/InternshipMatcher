export type Internship = {
  id: string;
  title: string;
  company: string;
  logo: string;
  logoColor: string;
  location: string;
  mode: "Remote" | "Hybrid" | "On-site";
  type: string;
  salary: string;
  posted: string;
  duration: string;
  category: string;
  description: string;
  skills: string[];
  applicants: number;
  featured?: boolean;
};

export type Project = {
  id: string;
  name: string;
  description: string;
  tags: string[];
  link?: string;
};

export type Achievement = {
  id: string;
  title: string;
  event: string;
  detail: string;
  date: string;
  type: "Hackathon" | "Certification" | "Award";
};

export type Profile = {
  name: string;
  email: string;
  school: string;
  major: string;
  year: string;
  location: string;
  bio: string;
  skills: string[];
  interests: string[];
  projects: Project[];
  certifications: string[];
};

export type ApplicationStatus = "Applied" | "In review" | "Interview" | "Offer" | "Not selected";

export type Application = {
  id: string;
  internshipId: string;
  status: ApplicationStatus;
  appliedAt: string;
};

export type Candidate = {
  id: string;
  name: string;
  initials: string;
  major: string;
  school: string;
  year: string;
  location: string;
  skills: string[];
  certifications: string[];
  interest: string;
  projects: number;
  hackathons: number;
  match: number;
};

export const initialInternships: Internship[] = [
  {
    id: "python-developer",
    title: "Python Developer Intern",
    company: "Northstar Labs",
    logo: "N",
    logoColor: "lavender",
    location: "New York, NY",
    mode: "Hybrid",
    type: "Internship",
    salary: "$32–38 / hr",
    posted: "2 days ago",
    duration: "12 weeks",
    category: "Software development",
    description: "Join a close-knit engineering team building tools that make complex data easier to understand. You’ll ship production-ready Python features, collaborate in code reviews, and work alongside mentors who care about your growth.",
    skills: ["Python", "FastAPI", "SQL", "Git"],
    applicants: 48,
    featured: true,
  },
  {
    id: "frontend-engineer",
    title: "Frontend Engineer Intern",
    company: "Fable Studio",
    logo: "F",
    logoColor: "peach",
    location: "Remote · US",
    mode: "Remote",
    type: "Internship",
    salary: "$28–34 / hr",
    posted: "1 day ago",
    duration: "10 weeks",
    category: "Software development",
    description: "Help bring joyful, accessible experiences to life. You’ll work with designers and engineers to build thoughtful interfaces, learn modern frontend practices, and own a feature from first sketch through launch.",
    skills: ["React", "TypeScript", "CSS", "Accessibility"],
    applicants: 72,
    featured: true,
  },
  {
    id: "data-analyst",
    title: "Data Analytics Intern",
    company: "Brightside Health",
    logo: "B",
    logoColor: "mint",
    location: "Boston, MA",
    mode: "Hybrid",
    type: "Internship",
    salary: "$30–36 / hr",
    posted: "3 days ago",
    duration: "12 weeks",
    category: "Data & analytics",
    description: "Turn healthcare data into insights that make care more human. Partner with analysts, ask good questions, and translate findings into clear stories for teams across the company.",
    skills: ["SQL", "Python", "Tableau", "Statistics"],
    applicants: 39,
    featured: true,
  },
  {
    id: "ux-design",
    title: "Product Design Intern",
    company: "Orbit Financial",
    logo: "O",
    logoColor: "sky",
    location: "San Francisco, CA",
    mode: "Hybrid",
    type: "Internship",
    salary: "$27–33 / hr",
    posted: "5 days ago",
    duration: "Summer · 12 weeks",
    category: "Design & product",
    description: "Make money feel less intimidating. Join our product design group to research real customer needs, explore concepts, and craft intuitive mobile-first experiences with a collaborative team.",
    skills: ["Figma", "Prototyping", "User research", "Design systems"],
    applicants: 55,
  },
  {
    id: "ai-research",
    title: "AI Research Intern",
    company: "Cohere Systems",
    logo: "C",
    logoColor: "lilac",
    location: "Remote · US",
    mode: "Remote",
    type: "Internship",
    salary: "$38–45 / hr",
    posted: "Today",
    duration: "16 weeks",
    category: "AI & machine learning",
    description: "Explore practical ways to make language models more useful. You’ll prototype research ideas, evaluate model behavior, and present findings to an interdisciplinary team.",
    skills: ["Python", "Machine Learning", "PyTorch", "Research"],
    applicants: 81,
    featured: true,
  },
  {
    id: "product-growth",
    title: "Product Growth Intern",
    company: "Morrow",
    logo: "M",
    logoColor: "butter",
    location: "Austin, TX",
    mode: "On-site",
    type: "Internship",
    salary: "$25–30 / hr",
    posted: "4 days ago",
    duration: "10 weeks",
    category: "Design & product",
    description: "Help a fast-growing product find its next million users. Work with the product team to research opportunities, run experiments, and turn what you learn into meaningful improvements.",
    skills: ["Product thinking", "Analytics", "Communication", "SQL"],
    applicants: 31,
  },
  {
    id: "security-engineer",
    title: "Security Engineering Intern",
    company: "Kiteworks",
    logo: "K",
    logoColor: "rose",
    location: "Seattle, WA",
    mode: "Hybrid",
    type: "Internship",
    salary: "$34–40 / hr",
    posted: "1 week ago",
    duration: "12 weeks",
    category: "Software development",
    description: "Help keep the internet a little safer. Learn from security engineers as you build internal tooling, investigate vulnerabilities, and make security a natural part of product development.",
    skills: ["Python", "Linux", "Networking", "Security"],
    applicants: 26,
  },
  {
    id: "fullstack-engineer",
    title: "Full Stack Developer Intern",
    company: "Goodkind",
    logo: "G",
    logoColor: "mint",
    location: "Chicago, IL",
    mode: "Remote",
    type: "Internship",
    salary: "$29–35 / hr",
    posted: "6 days ago",
    duration: "12 weeks",
    category: "Software development",
    description: "Build delightful software for independent businesses. You’ll contribute across the stack, pair with supportive teammates, and see your work make a difference for real customers.",
    skills: ["React", "Node.js", "PostgreSQL", "TypeScript"],
    applicants: 44,
  },
  {
    id: "climate-data",
    title: "Climate Data Intern",
    company: "Evergreen Impact",
    logo: "E",
    logoColor: "sage",
    location: "Denver, CO",
    mode: "Hybrid",
    type: "Internship",
    salary: "$26–32 / hr",
    posted: "1 week ago",
    duration: "Summer · 14 weeks",
    category: "Data & analytics",
    description: "Use open data and practical analytics to support a cleaner future. Help our impact team build clear dashboards, validate data, and share evidence that moves climate action forward.",
    skills: ["Python", "Data analysis", "GIS", "Storytelling"],
    applicants: 22,
  },
  {
    id: "marketing-creative",
    title: "Creative Marketing Intern",
    company: "Daybreak Coffee",
    logo: "D",
    logoColor: "peach",
    location: "Remote · US",
    mode: "Remote",
    type: "Internship",
    salary: "$22–26 / hr",
    posted: "2 weeks ago",
    duration: "10 weeks",
    category: "Marketing & creative",
    description: "Bring an independent coffee brand to more morning routines. Create content, learn what resonates with our community, and collaborate on a campaign from the first idea to its results.",
    skills: ["Content creation", "Social media", "Canva", "Analytics"],
    applicants: 36,
  },
];

export const defaultProfile: Profile = {
  name: "Alex Morgan",
  email: "alex.morgan@university.edu",
  school: "University of California, Berkeley",
  major: "Computer Science",
  year: "Junior · Class of 2027",
  location: "Berkeley, CA",
  bio: "Curious computer science student who loves turning thoughtful ideas into useful products. I’m especially interested in AI, accessible technology, and building with people who care about their work.",
  skills: ["Python", "FastAPI", "SQL", "Git", "React", "TypeScript", "Machine Learning", "Figma", "Data Analysis"],
  interests: ["Software development", "AI & machine learning", "Data & analytics"],
  projects: [
    { id: "p-1", name: "StudyFlow — smarter study groups", description: "Built a study buddy matching app for 400+ students using Python, FastAPI and React.", tags: ["Python", "FastAPI", "React"], link: "github.com/alexmorgan/studyflow" },
    { id: "p-2", name: "Campus Climate Dashboard", description: "An interactive dashboard that makes campus sustainability data easy to explore.", tags: ["SQL", "Data Analysis", "Figma"] },
  ],
  certifications: ["AWS Cloud Practitioner", "Google Data Analytics Certificate"],
};

export const initialAchievements: Achievement[] = [
  { id: "a-1", title: "1st Place · Social Impact Track", event: "Cal Hacks 10.0", detail: "Built a resource-matching tool for local food banks with a team of four.", date: "Nov 2025", type: "Hackathon" },
  { id: "a-2", title: "Finalist · Best Use of AI", event: "Hack the North", detail: "Created an accessible study companion using natural language search.", date: "Sep 2025", type: "Hackathon" },
  { id: "a-3", title: "AWS Cloud Practitioner", event: "Amazon Web Services", detail: "Validated foundational cloud concepts and core AWS services.", date: "Jun 2025", type: "Certification" },
];

export const candidates: Candidate[] = [
  { id: "cand-1", name: "Alex Morgan", initials: "AM", major: "Computer Science", school: "UC Berkeley", year: "Junior", location: "Berkeley, CA", skills: ["Python", "React", "SQL", "FastAPI"], certifications: ["AWS Cloud Practitioner", "GitHub Foundations"], interest: "AI & software", projects: 4, hackathons: 3, match: 96 },
  { id: "cand-2", name: "Jordan Lee", initials: "JL", major: "Data Science", school: "Stanford University", year: "Senior", location: "Palo Alto, CA", skills: ["Python", "SQL", "Machine Learning", "Tableau"], certifications: ["Google Data Analytics", "TensorFlow Developer"], interest: "Data & climate", projects: 5, hackathons: 2, match: 93 },
  { id: "cand-3", name: "Samira Patel", initials: "SP", major: "Human-Computer Interaction", school: "Carnegie Mellon", year: "Junior", location: "Pittsburgh, PA", skills: ["Figma", "Prototyping", "Research", "React"], certifications: ["Google UX Design", "Figma Essentials"], interest: "Product design", projects: 6, hackathons: 4, match: 91 },
  { id: "cand-4", name: "Noah Williams", initials: "NW", major: "Computer Engineering", school: "Georgia Tech", year: "Sophomore", location: "Atlanta, GA", skills: ["TypeScript", "Node.js", "React", "Git"], certifications: ["AWS Cloud Practitioner"], interest: "Full-stack", projects: 3, hackathons: 2, match: 87 },
  { id: "cand-5", name: "Ava Chen", initials: "AC", major: "Statistics & CS", school: "University of Michigan", year: "Senior", location: "Ann Arbor, MI", skills: ["Python", "Statistics", "SQL", "R"], certifications: ["Google Data Analytics", "Tableau Desktop Specialist"], interest: "Health analytics", projects: 4, hackathons: 1, match: 84 },
  { id: "cand-6", name: "Ethan Rivera", initials: "ER", major: "Information Systems", school: "UT Austin", year: "Junior", location: "Austin, TX", skills: ["Figma", "Analytics", "Product thinking", "SQL"], certifications: ["Meta Product Management"], interest: "Product growth", projects: 3, hackathons: 2, match: 81 },
];

const normalize = (value: string) => value.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();

export function calculateMatch(internship: Internship, profile: Profile, achievements: Achievement[] = []): number {
  const studentSkills = new Set(profile.skills.map(normalize));
  const matchingSkills = internship.skills.filter((skill) => studentSkills.has(normalize(skill))).length;
  const skillScore = internship.skills.length ? (matchingSkills / internship.skills.length) * 30 : 0;
  const searchable = normalize(`${internship.category} ${internship.title} ${internship.description}`);
  const interestHit = profile.interests.some((interest) => {
    const words = normalize(interest).split(" ").filter((word) => word.length > 3);
    return words.some((word) => searchable.includes(word));
  });
  const interestScore = interestHit ? 6 : 3;
  const projectOverlap = profile.projects.some((project) =>
    project.tags.some((tag) => internship.skills.some((skill) => normalize(skill) === normalize(tag))),
  );
  const projectScore = Math.min(4, profile.projects.length + (projectOverlap ? 2 : 0));
  const certificationScore = profile.certifications.length > 0 ? 1 : 0;
  const hackathonScore = achievements.some((achievement) => achievement.type === "Hackathon") ? 1 : 0;
  return Math.min(99, Math.round(50 + skillScore + interestScore + projectScore + certificationScore + hackathonScore));
}

export function getSkillOverlap(internship: Internship, skills: string[]) {
  const existing = new Set(skills.map(normalize));
  return {
    matched: internship.skills.filter((skill) => existing.has(normalize(skill))),
    missing: internship.skills.filter((skill) => !existing.has(normalize(skill))),
  };
}

export function formatDate(isoDate: string) {
  const date = new Date(isoDate);
  return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric" }).format(date);
}
