"use client";

import Link from "next/link";
import { ArrowRight, Compass, GraduationCap, Search, Sparkles, BriefcaseBusiness } from "lucide-react";
import { BrandLogo } from "@/components/common";

const steps = [
  { number: "01", title: "Build your profile", description: "Add skills, projects and achievements.", icon: GraduationCap },
  { number: "02", title: "Discover roles", description: "Browse internships that fit you.", icon: Search },
  { number: "03", title: "Get match scores", description: "See how well you fit each role.", icon: Sparkles },
  { number: "04", title: "Apply & track", description: "Apply and follow every application.", icon: BriefcaseBusiness },
];

export function LandingPage() {
  return (
    <div className="landing-page">
      <header className="site-header">
        <BrandLogo />
        <div className="site-actions">
          <Link className="site-signin" href="/login">Sign in</Link>
          <Link className="btn btn-primary btn-sm" href="/login">Get started <ArrowRight size={14} /></Link>
        </div>
      </header>

      <main>
        <section className="image-hero">
          <img className="image-hero-bg" src="/images/ai-brain-hero.jpg" alt="Hand presenting a glowing artificial intelligence brain" />
          <div className="image-hero-scrim" />
          <div className="image-hero-inner">
            <span className="hero-pill"><Sparkles size={13} /> AI-powered internship matching</span>
            <h1>Find internships that <em>match you.</em></h1>
            <p>InternMatch AI analyzes your skills, interests, projects and hackathon achievements to recommend internships where you have the strongest potential.</p>
            <div className="simple-hero-ctas">
              <Link className="btn btn-primary" href="/login">Find my internship <ArrowRight size={15} /></Link>
              <Link className="btn btn-outline-light" href="/explore">Explore opportunities <Compass size={15} /></Link>
            </div>
            <p className="image-hero-footnote">Your Skills. Your Potential. Your Opportunity.</p>
          </div>
        </section>

        <section className="section home-steps" id="how-it-works">
          <div className="section-inner">
            <div className="section-heading">
              <p className="section-kicker">How it works</p>
              <h2>Four steps to your next internship.</h2>
            </div>
            <div className="steps-grid">
              {steps.map((step) => {
                const Icon = step.icon;
                return <article className="step-card" key={step.number}><span className="step-no">STEP {step.number}</span><span className="step-icon"><Icon size={19} /></span><h3>{step.title}</h3><p>{step.description}</p></article>;
              })}
            </div>
          </div>
        </section>

        <section className="section" style={{ paddingTop: 0 }}>
          <div className="section-inner">
            <div className="home-cta">
              <h2>Ready to find your match?</h2>
              <div className="home-cta-actions">
                <Link className="btn btn-white" href="/login">Get started <ArrowRight size={15} /></Link>
                <Link className="btn btn-outline" href="/explore">Browse internships</Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="landing-footer">
        <BrandLogo />
        <span>© 2026 InternMatch AI</span>
        <div className="footer-links">
          <Link href="/login">Student sign in</Link>
          <Link href="/admin/login">Recruiter sign in</Link>
          <Link href="/dashboard">Dashboard</Link>
        </div>
      </footer>
    </div>
  );
}
