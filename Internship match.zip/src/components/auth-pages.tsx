"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, ArrowRight, BadgeCheck, BriefcaseBusiness, Check, GraduationCap, LockKeyhole, Sparkles, Users } from "lucide-react";
import { useDemo } from "@/lib/demo-store";
import { BrandLogo } from "@/components/common";

function AuthBackdrop({ admin = false }: { admin?: boolean }) {
  return <section className="login-brand-panel"><BrandLogo light /><div className="login-brand-message"><span className="eyebrow"><i className="eyebrow-dot" />{admin ? "A BETTER WAY TO FIND YOUR NEXT GREAT HIRE" : "YOUR NEXT CHAPTER STARTS HERE"}</span><h1>{admin ? <>Find the people behind the <span>potential.</span></> : <>Your skills. Your potential. <span>Your opportunity.</span></>}</h1><p>{admin ? "Discover motivated students through the projects, skills and achievements that don’t always fit on a résumé." : "Build a fuller picture of what you can do, then find internships that see your potential."}</p><div className="login-points"><div className="login-point"><Check size={14} />{admin ? "Spot skills that matter for the role" : "Matches built around your real experience"}</div><div className="login-point"><Check size={14} />{admin ? "Explore projects and hackathon work" : "Make your projects and achievements count"}</div><div className="login-point"><Check size={14} />{admin ? "Create a clear, collaborative shortlist" : "A private, local demo account—no API needed"}</div></div></div><div className="login-panel-footer">© 2026 InternMatch AI · {admin ? "Recruiter workspace" : "Built for your next opportunity"}</div></section>;
}

export function StudentLoginPage() {
  const { state, signIn } = useDemo();
  const router = useRouter();
  const [name, setName] = useState(state.profile.name);
  const [email, setEmail] = useState(state.profile.email);
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!name.trim() || !email.includes("@") || password.trim().length < 4) { setError("Enter your name, a valid email, and a password with at least four characters."); return; }
    signIn("student", name.trim(), email.trim());
    router.push("/dashboard");
  }

  function useDemoProfile() {
    signIn("student");
    router.push("/dashboard");
  }

  return <div className="login-page"><AuthBackdrop /><section className="login-form-panel"><div className="login-form-wrap"><Link className="back-link" href="/"><ArrowLeft size={13} /> Back to InternMatch AI</Link><div className="login-form-icon"><GraduationCap size={18} /></div><h2>Welcome back.</h2><p>Sign in to your student workspace—or jump right into the demo.</p><form onSubmit={submit}><div className="form-field"><label className="field-label" htmlFor="student-name">Your name</label><input className="field-input" id="student-name" value={name} onChange={(event) => setName(event.target.value)} placeholder="Alex Morgan" autoComplete="name" required /></div><div className="form-field"><label className="field-label" htmlFor="student-email">College email</label><input className="field-input" id="student-email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@university.edu" autoComplete="email" required /></div><div className="form-field"><label className="field-label" htmlFor="student-password">Password</label><input className="field-input" id="student-password" type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="At least 4 characters for this demo" autoComplete="current-password" required minLength={4} /></div>{error && <div className="inline-feedback error">{error}</div>}<button className="btn btn-primary btn-full" type="submit">Sign in to my workspace <ArrowRight size={14} /></button></form><div className="login-separator">or</div><button className="btn btn-outline btn-full" type="button" onClick={useDemoProfile}><Sparkles size={14} />Continue with Alex’s demo profile</button><div className="demo-note"><strong>Demo mode:</strong> No account or network request required. Your edits are saved only in this browser.</div><div className="auth-switch">Recruiter or admin? <Link href="/admin/login">Open recruiter sign in <ArrowRight size={12} /></Link></div><div className="auth-explore"><Link href="/explore">Browse internships without signing in <ArrowRight size={12} /></Link></div></div></section></div>;
}

export function AdminLoginPage() {
  const { signIn } = useDemo();
  const router = useRouter();
  const [email, setEmail] = useState("taylor@internmatch.ai");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!email.includes("@") || password.trim().length < 4) { setError("Enter a valid work email and a password with at least four characters."); return; }
    signIn("admin");
    router.push("/admin/dashboard");
  }

  function enterDemo() {
    signIn("admin");
    router.push("/admin/dashboard");
  }

  return <div className="login-page"><AuthBackdrop admin /><section className="login-form-panel"><div className="login-form-wrap"><Link className="back-link" href="/"><ArrowLeft size={13} /> Back to InternMatch AI</Link><div className="login-form-icon recruiter"><BriefcaseBusiness size={17} /></div><h2>Recruiter workspace.</h2><p>See the potential behind the profile and make your next great match.</p><form onSubmit={submit}><div className="form-field"><label className="field-label" htmlFor="admin-email">Work email</label><input className="field-input" id="admin-email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="username" required /></div><div className="form-field"><label className="field-label" htmlFor="admin-password">Password</label><input className="field-input" id="admin-password" type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="At least 4 characters for this demo" autoComplete="current-password" minLength={4} required /></div>{error && <div className="inline-feedback error">{error}</div>}<button className="btn btn-primary btn-full" type="submit">Sign in to recruiter workspace <ArrowRight size={14} /></button></form><div className="login-separator">or</div><button className="btn btn-outline btn-full" type="button" onClick={enterDemo}><Users size={14} />Explore the recruiter demo</button><div className="demo-note"><strong>Demo mode:</strong> Use any valid email and a password with at least four characters, or enter the demo directly. No backend required.</div><div className="auth-switch">Looking for an internship? <Link href="/login">Student sign in <ArrowRight size={12} /></Link></div><div className="auth-explore"><Link href="/admin/dashboard">Open recruiter dashboard <ArrowRight size={12} /></Link></div></div></section></div>;
}
