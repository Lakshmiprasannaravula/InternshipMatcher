"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";
import type { LucideIcon } from "lucide-react";
import {
  Activity,
  ArrowRight,
  Award,
  Bell,
  Bot,
  BriefcaseBusiness,
  Check,
  ChevronRight,
  CircleUserRound,
  Compass,
  FileText,
  GraduationCap,
  Heart,
  Home,
  Lightbulb,
  LogOut,
  Map,
  Plus,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  Target,
  Users,
  X,
} from "lucide-react";
import { calculateMatch, type Internship } from "@/lib/data";
import { useDemo } from "@/lib/demo-store";

export function BrandLogo({ light = false }: { light?: boolean }) {
  return (
    <Link className={`brand-lockup${light ? " light" : ""}`} href="/" aria-label="InternMatch AI home">
      <span className="brand-symbol" aria-hidden="true">
        <GraduationCap />
        <BriefcaseBusiness className="brand-mini" />
        <i className="brand-network" />
      </span>
      <span className="brand-word">InternMatch <span>AI</span></span>
    </Link>
  );
}

function initials(name: string) {
  return name.split(" ").filter(Boolean).slice(0, 2).map((part) => part[0]?.toUpperCase()).join("") || "IM";
}

type NavItem = { label: string; href: string; icon: LucideIcon; group?: string; badge?: boolean; mobileHidden?: boolean };

const studentNavigation: NavItem[] = [
  { label: "Overview", href: "/dashboard", icon: Home, group: "Workspace" },
  { label: "Explore internships", href: "/explore", icon: Compass, group: "Workspace" },
  { label: "AI matches", href: "/matches", icon: Sparkles, group: "Workspace" },
  { label: "Applications", href: "/applications", icon: BriefcaseBusiness, group: "Workspace", badge: true },
  { label: "My profile", href: "/profile", icon: CircleUserRound, group: "Workspace" },
  { label: "AI Chatbot", href: "/chatbot", icon: Bot, group: "Workspace" },
  { label: "Skill gap analyzer", href: "/skills", icon: Activity, group: "Your toolkit", mobileHidden: true },
  { label: "Resume analyzer", href: "/resume", icon: FileText, group: "Your toolkit", mobileHidden: true },
  { label: "Career roadmap", href: "/roadmap", icon: Map, group: "Your toolkit", mobileHidden: true },
  { label: "Achievements", href: "/achievements", icon: Award, group: "Your toolkit", mobileHidden: true },
];

const adminNavigation: NavItem[] = [
  { label: "Overview", href: "/admin/dashboard", icon: Home },
  { label: "Candidates", href: "/admin/candidates", icon: Users },
  { label: "Internships", href: "/admin/internships", icon: BriefcaseBusiness },
  { label: "Shortlist", href: "/admin/shortlist", icon: Heart },
];

const pageDirectoryGroups: { title: string; pages: NavItem[] }[] = [
  {
    title: "Student pages",
    pages: [
      { label: "Student sign in", href: "/login", icon: GraduationCap },
      { label: "Student dashboard", href: "/dashboard", icon: Home },
      { label: "Student profile", href: "/profile", icon: CircleUserRound },
      { label: "Explore internships", href: "/explore", icon: Compass },
      { label: "Internship details", href: "/internships/python-developer", icon: BriefcaseBusiness },
      { label: "AI match analysis", href: "/matches", icon: Sparkles },
      { label: "AI Chatbot & Resume Review", href: "/chatbot", icon: Bot },
      { label: "Skill gap analyzer", href: "/skills", icon: Activity },
      { label: "Resume analyzer", href: "/resume", icon: FileText },
      { label: "Application tracker", href: "/applications", icon: BriefcaseBusiness },
      { label: "Career roadmap", href: "/roadmap", icon: Map },
      { label: "Achievements portfolio", href: "/achievements", icon: Award },
    ],
  },
  {
    title: "Recruiter pages",
    pages: [
      { label: "Recruiter sign in", href: "/admin/login", icon: ShieldCheck },
      { label: "Recruiter dashboard", href: "/admin/dashboard", icon: Home },
      { label: "Candidate management", href: "/admin/candidates", icon: Users },
      { label: "Internship management", href: "/admin/internships", icon: BriefcaseBusiness },
      { label: "Shortlist management", href: "/admin/shortlist", icon: Heart },
    ],
  },
];

export function PageDirectoryMenu() {
  const [open, setOpen] = useState(false);
  return (
    <div className="pages-menu">
      <button className={`pages-menu-trigger${open ? " open" : ""}`} type="button" aria-label="Browse all website pages" aria-expanded={open} aria-haspopup="dialog" onClick={() => setOpen((value) => !value)}>
        <Compass size={14} /> <span>All pages</span> <ChevronRight className="pages-menu-chevron" size={12} />
      </button>
      {open && (
        <>
          <button className="pages-menu-backdrop" type="button" aria-label="Close page menu" onClick={() => setOpen(false)} />
          <section className="pages-menu-panel" role="dialog" aria-label="Website page directory">
            <div className="pages-menu-heading"><div><span>INTERNMATCH AI · PAGE DIRECTORY</span><strong>Every experience, one website.</strong></div><button className="btn-icon" type="button" onClick={() => setOpen(false)} aria-label="Close page directory"><X size={14} /></button></div>
            <div className="pages-menu-groups">
              {pageDirectoryGroups.map((group) => (
                <section className="pages-menu-group" key={group.title}>
                  <h2>{group.title}</h2>
                  <div>{group.pages.map((page) => { const Icon = page.icon; return <Link href={page.href} key={page.href} onClick={() => setOpen(false)}><Icon /><span>{page.label}</span><ChevronRight className="directory-arrow" /></Link>; })}</div>
                </section>
              ))}
            </div>
            <div className="pages-menu-account"><span>Account</span><Link href="/" onClick={() => setOpen(false)}>Home</Link><Link href="/logout" onClick={() => setOpen(false)}><LogOut size={12} /> Log out</Link></div>
          </section>
        </>
      )}
    </div>
  );
}

export function AppShell({ children, admin = false }: { children: ReactNode; admin?: boolean }) {
  const pathname = usePathname();
  const { state } = useDemo();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const links = admin ? adminNavigation : studentNavigation;

  function isActive(href: string) {
    return pathname === href || ((href !== "/dashboard" && href !== "/admin/dashboard") && pathname.startsWith(`${href}/`));
  }

  return (
    <div className="app-layout">
      <aside className={`app-sidebar${admin ? " admin-sidebar" : ""}`}>
        <BrandLogo light />
        <div className="sidebar-label">{admin ? "Recruiter workspace" : "Workspace"}</div>
        <nav className="sidebar-nav" aria-label={admin ? "Recruiter navigation" : "Student navigation"}>
          {links.map((item, index) => {
            const Icon = item.icon;
            const active = isActive(item.href);
            const previous = links[index - 1];
            const groupChanged = Boolean(previous && item.group && item.group !== previous.group);
            return (
              <div key={item.href} className={groupChanged ? "nav-group-start" : undefined}>
                {groupChanged && <div className="sidebar-label sidebar-secondary-label">{item.group}</div>}
                <Link className={`sidebar-link${active ? " active" : ""}${item.mobileHidden ? " mobile-secondary" : ""}`} href={item.href} aria-current={active ? "page" : undefined}>
                  <Icon />
                  <span>{item.label}</span>
                  {item.badge && state.applications.length > 0 && <span className="sidebar-badge">{state.applications.length}</span>}
                </Link>
              </div>
            );
          })}
          <button className={`sidebar-link sidebar-more-link${mobileMenuOpen ? " active" : ""}`} type="button" onClick={() => setMobileMenuOpen((value) => !value)} aria-expanded={mobileMenuOpen} aria-label="More pages and account options"><Settings2 /><span>More</span></button>
        </nav>
        {!admin && (
          <>
            <div className="sidebar-spacer" />
            <div className="sidebar-tip">
              <span className="tip-icon"><Lightbulb size={15} /></span>
              <strong>Your next step is waiting</strong>
              <p>One small profile update can unlock better matches.</p>
              <Link href="/profile">Strengthen your profile <ArrowRight size={11} /></Link>
            </div>
          </>
        )}
        <div className="sidebar-user">
          <span className={`avatar${admin ? " green" : ""}`}>{admin ? "AD" : initials(state.profile.name)}</span>
          <div className="sidebar-user-copy">
            <strong>{admin ? "Taylor Admin" : state.profile.name}</strong>
            <span>{admin ? "Talent team" : "Student account"}</span>
          </div>
          <Link className="sidebar-logout" href="/logout" title="Sign out" aria-label="Sign out"><LogOut size={14} /></Link>
        </div>
        {mobileMenuOpen && (
          <div className="mobile-menu-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setMobileMenuOpen(false); }}>
            <section className="mobile-menu-sheet" role="dialog" aria-modal="true" aria-labelledby="mobile-menu-title">
              <div className="mobile-menu-heading"><div><span>INTERNMATCH AI</span><h2 id="mobile-menu-title">All {admin ? "recruiter" : "student"} pages</h2></div><button className="btn-icon" type="button" onClick={() => setMobileMenuOpen(false)} aria-label="Close menu"><X size={15} /></button></div>
              <nav className="mobile-menu-links" aria-label="All workspace pages">{links.map((item) => { const Icon = item.icon; return <Link href={item.href} className={isActive(item.href) ? "active" : ""} key={item.href} onClick={() => setMobileMenuOpen(false)}><Icon /><span>{item.label}</span><ChevronRight /></Link>; })}</nav>
              <div className="mobile-menu-account"><span>ACCOUNT</span><div><Link href={admin ? "/admin/login" : "/login"} onClick={() => setMobileMenuOpen(false)}><CircleUserRound /> Switch account</Link><Link href="/" onClick={() => setMobileMenuOpen(false)}><Home /> Home page</Link><Link className="mobile-logout-link" href="/logout" onClick={() => setMobileMenuOpen(false)}><LogOut /> Log out</Link></div></div>
            </section>
          </div>
        )}
      </aside>
      <div className="app-main-wrap">
        <header className="app-topbar">
          <div className="mobile-brand"><BrandLogo /></div>
          <div className="topbar-left"><span>InternMatch AI</span><ChevronRight /><strong>{admin ? "Recruiter workspace" : "Student workspace"}</strong></div>
          <div className="topbar-right">
            <Link className="topbar-search" href={admin ? "/admin/candidates" : "/explore"} aria-label={admin ? "Search candidates" : "Search internships"}>
              <Search size={14} /><span>{admin ? "Find candidates" : "Search opportunities"}</span>
            </Link>
            <Link className="topbar-icon" href={admin ? "/admin/shortlist" : "/applications"} aria-label={admin ? "View shortlist" : "View applications"}>
              <Bell size={15} /><i className="notification-dot" />
            </Link>
            <Link className="topbar-user" href={admin ? "/admin/dashboard" : "/profile"} aria-label={admin ? "Recruiter dashboard" : "Student profile"}>
              <span className={`avatar sm${admin ? " green" : ""}`}>{admin ? "AD" : initials(state.profile.name)}</span>
              <span>{admin ? "Taylor" : state.profile.name.split(" ")[0]}</span>
            </Link>
          </div>
        </header>
        <main className="app-content">{children}</main>
      </div>
    </div>
  );
}

export function PageHeader({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="page-heading">
      <div>
        {eyebrow && <div className="breadcrumb"><span>{eyebrow}</span><ChevronRight /> <span>{title}</span></div>}
        <h1>{title}</h1>
        {description && <p>{description}</p>}
      </div>
      {action && <div className="page-heading-actions">{action}</div>}
    </div>
  );
}

export function CompanyLogo({ internship, small = false }: { internship: Internship; small?: boolean }) {
  return <span className={`company-logo logo-${internship.logoColor}${small ? " sm" : ""}`}>{internship.logo}</span>;
}

export function MatchBadge({ score }: { score: number }) {
  return <span className="match-badge"><Sparkles /> {score}% match</span>;
}

export function InternshipCard({ internship, quickApply = false }: { internship: Internship; quickApply?: boolean }) {
  const { state, toggleSaved, applyToInternship } = useDemo();
  const [message, setMessage] = useState("");
  const score = calculateMatch(internship, state.profile, state.achievements);
  const saved = state.savedInternships.includes(internship.id);
  const applied = state.applications.some((item) => item.internshipId === internship.id);

  function handleApply() {
    setMessage(applyToInternship(internship.id) ? "Application added to your tracker." : "You’ve already applied — check your tracker.");
  }

  return (
    <article className="internship-card">
      <div className="internship-card-head">
        <CompanyLogo internship={internship} />
        <button className={`btn-icon save-toggle${saved ? " active" : ""}`} type="button" onClick={() => toggleSaved(internship.id)} aria-label={saved ? "Remove saved internship" : "Save internship"} title={saved ? "Saved" : "Save internship"}>
          <Heart size={15} fill={saved ? "currentColor" : "none"} />
        </button>
      </div>
      <div className="internship-card-title" style={{ marginTop: 12 }}>
        <h3><Link href={`/internships/${internship.id}`}>{internship.title}</Link></h3>
        <p>{internship.company}</p>
      </div>
      <div className="card-location">
        <span><Compass />{internship.location}</span>
        <span><BriefcaseBusiness />{internship.mode}</span>
      </div>
      <div className="card-skills">{internship.skills.slice(0, 3).map((skill) => <span className={`skill-pill${state.profile.skills.some((s) => s.toLowerCase() === skill.toLowerCase()) ? " match" : ""}`} key={skill}>{skill}</span>)}</div>
      {message && <p className="card-feedback"><Check size={11} />{message}</p>}
      <div className="card-footer">
        <MatchBadge score={score} />
        {quickApply ? (
          applied ? <Link className="text-link" href="/applications">Applied <Check /></Link> : <button className="text-link card-apply" type="button" onClick={handleApply}>Quick apply <ArrowRight /></button>
        ) : <Link className="text-link" href={`/internships/${internship.id}`}>View role <ArrowRight /></Link>}
      </div>
    </article>
  );
}

export function StatCard({ title, value, hint, icon, tone = "purple" }: { title: string; value: string | number; hint: string; icon: ReactNode; tone?: "purple" | "blue" | "green" | "orange" }) {
  return (
    <div className="stat-card">
      <div className="stat-card-top"><span>{title}</span><span className={`stat-icon${tone === "purple" ? "" : ` ${tone}`}`}>{icon}</span></div>
      <div className="stat-number">{value}</div>
      <div className="stat-footnote">{hint}</div>
    </div>
  );
}

export function Modal({ title, description, onClose, children }: { title: string; description?: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <div className="modal-heading">
          <div><h2 id="modal-title">{title}</h2>{description && <p>{description}</p>}</div>
          <button className="btn-icon" type="button" onClick={onClose} aria-label="Close dialog"><X size={15} /></button>
        </div>
        {children}
      </section>
    </div>
  );
}

export function EmptyState({ title, description, action, icon }: { title: string; description: string; action?: ReactNode; icon?: ReactNode }) {
  return <div className="empty-state">{icon ?? <Target size={24} />}<strong>{title}</strong><p>{description}</p>{action}</div>;
}

export function Feedback({ children, error = false }: { children: ReactNode; error?: boolean }) {
  return <div className={`inline-feedback${error ? " error" : ""}`}>{error ? <X /> : <Check />}{children}</div>;
}

export function PageActionLink({ href, children }: { href: string; children: ReactNode }) {
  return <Link className="btn btn-primary" href={href}>{children}<ArrowRight size={15} /></Link>;
}

export function CompactIcon({ icon, label }: { icon: ReactNode; label: string }) {
  return <span className="compact-icon" title={label}>{icon}</span>;
}

export function FormSubmit({ children }: { children: ReactNode }) {
  return <button className="btn btn-primary" type="submit">{children}<ArrowRight size={14} /></button>;
}

export function LinkedAction({ href, label, icon }: { href: string; label: string; icon?: ReactNode }) {
  return <Link className="btn btn-outline btn-sm" href={href}>{icon ?? <Settings2 size={13} />}{label}</Link>;
}

export function AddButton({ onClick, children }: { onClick: () => void; children: ReactNode }) {
  return <button className="btn btn-primary btn-sm" type="button" onClick={onClick}><Plus size={14} />{children}</button>;
}
