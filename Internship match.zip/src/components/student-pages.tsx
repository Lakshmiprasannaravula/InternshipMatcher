"use client";

import Link from "next/link";
import { useEffect, useMemo, useState, type FormEvent, type KeyboardEvent } from "react";
import {
  Activity,
  ArrowRight,
  Award,
  BadgeCheck,
  BookOpen,
  BriefcaseBusiness,
  Building2,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleDollarSign,
  Clock3,
  ExternalLink,
  FileText,
  Filter,
  Flag,
  FolderKanban,
  GraduationCap,
  Heart,
  Lightbulb,
  Map,
  MapPin,
  Plus,
  Search,
  Sparkles,
  Target,
  Trash2,
  TrendingUp,
  Trophy,
  Upload,
  X,
} from "lucide-react";
import {
  calculateMatch,
  formatDate,
  getSkillOverlap,
  type Achievement,
  type ApplicationStatus,
  type Internship,
  type Profile,
} from "@/lib/data";
import { useDemo } from "@/lib/demo-store";
import {
  AppShell,
  CompanyLogo,
  EmptyState,
  Feedback,
  InternshipCard,
  LinkedAction,
  MatchBadge,
  Modal,
  PageHeader,
  StatCard,
} from "@/components/common";

const categories = ["All opportunities", "Software development", "Data & analytics", "Design & product", "AI & machine learning", "Marketing & creative"];
const profileSkills = ["Python", "SQL", "React", "TypeScript", "Git", "Figma", "Machine Learning", "FastAPI", "Data Analysis", "Tableau", "Node.js", "Communication"];
const interestOptions = ["Software development", "AI & machine learning", "Data & analytics", "Design & product", "Climate tech", "Health tech", "Cybersecurity", "Marketing & creative"];

function fullNameInitials(name: string) {
  return name.split(" ").filter(Boolean).slice(0, 2).map((part) => part[0]?.toUpperCase()).join("") || "IM";
}

function profileCompletion(profile: Profile) {
  let points = 30;
  if (profile.bio.length > 30) points += 15;
  if (profile.skills.length >= 5) points += 20;
  if (profile.interests.length >= 2) points += 10;
  if (profile.projects.length > 0) points += 15;
  if (profile.certifications.length > 0) points += 10;
  return Math.min(100, points);
}

function sortedMatches(internships: Internship[], profile: Profile, achievements: Achievement[] = []) {
  return [...internships].sort((left, right) => calculateMatch(right, profile, achievements) - calculateMatch(left, profile, achievements));
}

function checkInitials(value: string) {
  return value.trim().toLowerCase();
}

export function StudentDashboard() {
  const { state } = useDemo();
  const completion = profileCompletion(state.profile);
  const matches = sortedMatches(state.internships, state.profile, state.achievements);
  const name = state.profile.name.split(" ")[0] || "there";
  const recentApplications = state.applications.slice(0, 3);

  return (
    <AppShell>
      <div className="welcome-banner">
        <div className="welcome-banner-copy"><span>Tuesday, February 17, 2026 · Your career workspace</span><h2>Good morning, {name} <span aria-hidden="true">✦</span></h2><p>Your next opportunity could be one thoughtful application away.</p></div>
        <Link className="btn btn-white btn-sm" href="/explore">Explore your matches <ArrowRight size={14} /></Link>
      </div>
      <PageHeader title="Your dashboard" description="A clearer path from what you can do to what you could do next." />
      <section className="stats-grid" aria-label="Your activity summary">
        <StatCard title="Strong matches" value={matches.filter((item) => calculateMatch(item, state.profile, state.achievements) >= 80).length} hint="Roles at 80% fit or higher" icon={<Sparkles />} />
        <StatCard title="Saved roles" value={state.savedInternships.length} hint="Opportunities you want to revisit" tone="blue" icon={<Heart />} />
        <StatCard title="Applications" value={state.applications.length} hint="Keep every next step in view" tone="green" icon={<BriefcaseBusiness />} />
        <StatCard title="Profile strength" value={`${completion}%`} hint="More detail means smarter matches" tone="orange" icon={<TrendingUp />} />
      </section>

      <div className="dashboard-grid">
        <section className="panel">
          <div className="panel-heading"><div><h2>Picked for your potential</h2><p>Sorted by how your experience connects</p></div><Link className="text-link" href="/matches">See all matches <ArrowRight /></Link></div>
          <div className="match-list">
            {matches.slice(0, 4).map((internship) => <div className="match-list-row" key={internship.id}>
              <CompanyLogo internship={internship} small />
              <div className="match-row-copy"><strong><Link href={`/internships/${internship.id}`}>{internship.title}</Link></strong><span>{internship.company} · {internship.location}</span><div className="card-skills">{internship.skills.slice(0, 3).map((skill) => <span className={`skill-pill${state.profile.skills.some((mine) => checkInitials(mine) === checkInitials(skill)) ? " match" : ""}`} key={skill}>{skill}</span>)}</div></div>
              <span className="match-percent">{calculateMatch(internship, state.profile, state.achievements)}%<small>match</small></span>
            </div>)}
          </div>
        </section>
        <section className="panel">
          <div className="panel-heading"><div><h2>Profile strength</h2><p>Show the person behind the résumé</p></div><Link className="text-link" href="/profile">Edit <ArrowRight /></Link></div>
          <div className="profile-progress"><div className="progress-ring" style={{ "--progress": `${completion}%` } as React.CSSProperties}><strong>{completion}%</strong></div><div className="profile-progress-copy"><strong>Looking promising!</strong><p>A few finishing touches can help the right teams find you.</p></div></div>
          <div className="progress-line"><span style={{ width: `${completion}%` }} /></div>
          <div className="progress-checklist">
            <div className="progress-check"><CheckCircle2 /> Basic info is ready</div>
            <div className={`progress-check${state.profile.skills.length < 5 ? " incomplete" : ""}`}>{state.profile.skills.length >= 5 ? <CheckCircle2 /> : <CircleDot />}Skills & interests</div>
            <div className={`progress-check${state.profile.projects.length < 1 ? " incomplete" : ""}`}>{state.profile.projects.length > 0 ? <CheckCircle2 /> : <CircleDot />}Add a project to show your work</div>
            <div className={`progress-check${state.achievements.length < 1 ? " incomplete" : ""}`}>{state.achievements.length > 0 ? <CheckCircle2 /> : <CircleDot />}Add a hackathon achievement</div>
          </div>
        </section>
      </div>

      <section style={{ marginTop: 19 }}>
        <div className="panel-heading"><div><h2 className="section-title-small">A few more worth a look</h2><p>New roles that line up with your interests</p></div><Link className="text-link" href="/explore">Browse all opportunities <ArrowRight /></Link></div>
        <div className="recommend-grid">{matches.slice(0, 3).map((internship) => <InternshipCard key={internship.id} internship={internship} quickApply />)}</div>
      </section>

      <section className="panel" style={{ marginTop: 18 }}>
        <div className="panel-heading"><div><h2>Application pulse</h2><p>Your latest steps forward</p></div><Link className="text-link" href="/applications">Open tracker <ArrowRight /></Link></div>
        {recentApplications.length ? <div className="application-list">{recentApplications.map((application) => {
          const internship = state.internships.find((item) => item.id === application.internshipId);
          if (!internship) return null;
          return <div className="application-row" key={application.id}><div className="application-company"><CompanyLogo internship={internship} small /><div><h3>{internship.title}</h3><p>{internship.company}</p></div></div><div className="application-meta"><small>Applied</small><span>{formatDate(application.appliedAt)}</span></div><div className="application-meta"><small>Current status</small><span className={`status-pill ${application.status.replaceAll(" ", "-")}`}>{application.status}</span></div><Link className="text-link" href={`/internships/${internship.id}`}>View role <ArrowRight /></Link></div>;
        })}</div> : <EmptyState title="Your application story starts here" description="Save a role or apply to add it to your tracker." action={<Link className="btn btn-primary btn-sm" href="/explore">Explore internships</Link>} />}
      </section>
    </AppShell>
  );
}

function CircleDot() {
  return <span className="circle-dot-outline" aria-hidden="true" />;
}

export function StudentProfilePage() {
  const { state, updateProfile, addProject, removeProject } = useDemo();
  const [draft, setDraft] = useState<Profile>(state.profile);
  const [skillInput, setSkillInput] = useState("");
  const [certInput, setCertInput] = useState("");
  const [saved, setSaved] = useState(false);
  const [projectModal, setProjectModal] = useState(false);
  const [projectName, setProjectName] = useState("");
  const [projectDescription, setProjectDescription] = useState("");
  const [projectTags, setProjectTags] = useState("");
  const [projectLink, setProjectLink] = useState("");

  useEffect(() => setDraft(state.profile), [state.profile]);

  function addSkill(value = skillInput) {
    const clean = value.trim();
    if (clean && !draft.skills.some((skill) => checkInitials(skill) === checkInitials(clean))) {
      setDraft((current) => ({ ...current, skills: [...current.skills, clean] }));
      setSaved(false);
    }
    setSkillInput("");
  }

  function addCertification() {
    const clean = certInput.trim();
    if (clean && !draft.certifications.includes(clean)) setDraft((current) => ({ ...current, certifications: [...current.certifications, clean] }));
    setCertInput("");
    setSaved(false);
  }

  function toggleInterest(interest: string) {
    setDraft((current) => ({ ...current, interests: current.interests.includes(interest) ? current.interests.filter((item) => item !== interest) : [...current.interests, interest] }));
    setSaved(false);
  }

  function handleSave(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    updateProfile(draft);
    setSaved(true);
  }

  function handleProjectSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!projectName.trim() || !projectDescription.trim()) return;
    addProject({ name: projectName.trim(), description: projectDescription.trim(), tags: projectTags.split(",").map((tag) => tag.trim()).filter(Boolean), ...(projectLink.trim() ? { link: projectLink.trim() } : {}) });
    setProjectName(""); setProjectDescription(""); setProjectTags(""); setProjectLink(""); setProjectModal(false);
  }

  function skillKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    if (event.key === "Enter" || event.key === ",") { event.preventDefault(); addSkill(); }
  }

  return (
    <AppShell>
      <PageHeader title="Your student profile" description="Give the matching engine a fuller picture of what makes you a great teammate." action={<Link className="btn btn-outline btn-sm" href="/matches"><Sparkles size={14} /> Preview my matches</Link>} />
      <div className="two-column">
        <section className="content-card">
          <div className="profile-cover"><div className="profile-avatar-large">{fullNameInitials(draft.name)}</div><div><h2>{draft.name}</h2><p>{draft.major} · {draft.school}</p><p>{draft.location} · {draft.year}</p></div></div>
          <form className="profile-card-body" onSubmit={handleSave}>
            <div className="panel-heading"><div><h2>About you</h2><p>These details help us find roles that fit your goals.</p></div><BadgeCheck size={17} color="#7667e7" /></div>
            <div className="field-row">
              <div className="form-field"><label className="field-label" htmlFor="profile-name">Full name</label><input id="profile-name" className="field-input" value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} required /></div>
              <div className="form-field"><label className="field-label" htmlFor="profile-email">Email address</label><input id="profile-email" className="field-input" type="email" value={draft.email} onChange={(event) => setDraft({ ...draft, email: event.target.value })} required /></div>
            </div>
            <div className="field-row">
              <div className="form-field"><label className="field-label" htmlFor="profile-school">College or university</label><input id="profile-school" className="field-input" value={draft.school} onChange={(event) => setDraft({ ...draft, school: event.target.value })} /></div>
              <div className="form-field"><label className="field-label" htmlFor="profile-major">Major or program</label><input id="profile-major" className="field-input" value={draft.major} onChange={(event) => setDraft({ ...draft, major: event.target.value })} /></div>
            </div>
            <div className="field-row">
              <div className="form-field"><label className="field-label" htmlFor="profile-year">Graduation year / class</label><input id="profile-year" className="field-input" value={draft.year} onChange={(event) => setDraft({ ...draft, year: event.target.value })} /></div>
              <div className="form-field"><label className="field-label" htmlFor="profile-location">Location</label><input id="profile-location" className="field-input" value={draft.location} onChange={(event) => setDraft({ ...draft, location: event.target.value })} /></div>
            </div>
            <div className="form-field"><label className="field-label" htmlFor="profile-bio">A little about you</label><textarea id="profile-bio" className="field-textarea" value={draft.bio} onChange={(event) => setDraft({ ...draft, bio: event.target.value })} placeholder="What are you curious about? What kind of problems do you like solving?" /></div>
            <div className="form-field"><label className="field-label" htmlFor="profile-skill-input">Your skills</label><div className="chips-editor">{draft.skills.map((skill) => <span className="editable-chip" key={skill}>{skill}<button type="button" aria-label={`Remove ${skill}`} onClick={() => setDraft({ ...draft, skills: draft.skills.filter((item) => item !== skill) })}><X size={11} /></button></span>)}<input id="profile-skill-input" value={skillInput} onChange={(event) => setSkillInput(event.target.value)} onKeyDown={skillKeyDown} placeholder="Type a skill and press Enter" /><button className="btn btn-outline btn-sm" type="button" onClick={() => addSkill()}>Add</button></div><div className="field-help">Add the skills you can demonstrate in a class, project or team.</div></div>
            <div className="form-field"><span className="field-label">Interests & role areas</span><div className="choice-chips">{interestOptions.map((interest) => <button className={`choice-chip${draft.interests.includes(interest) ? " selected" : ""}`} type="button" key={interest} onClick={() => toggleInterest(interest)}>{draft.interests.includes(interest) && <Check size={11} />}{interest}</button>)}</div></div>
            <div className="form-field"><label className="field-label" htmlFor="profile-cert">Certifications</label><div className="cert-add-row"><input id="profile-cert" className="field-input" value={certInput} onChange={(event) => setCertInput(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") { event.preventDefault(); addCertification(); } }} placeholder="Add a course or certification" /><button className="btn btn-outline btn-sm" type="button" onClick={addCertification}><Plus size={13} /> Add</button></div><div className="card-skills">{draft.certifications.map((cert) => <span className="editable-chip" key={cert}>{cert}<button type="button" aria-label={`Remove ${cert}`} onClick={() => setDraft({ ...draft, certifications: draft.certifications.filter((item) => item !== cert) })}><X size={11} /></button></span>)}</div></div>
            {saved && <Feedback>Your profile is saved. Your match scores now reflect these updates.</Feedback>}
            <button className="btn btn-primary" type="submit">Save profile <Check size={14} /></button>
          </form>
        </section>

        <div className="side-stack">
          <section className="panel">
            <div className="panel-heading"><div><h2>Projects that show your work</h2><p>What have you built, explored or improved?</p></div><button className="btn-icon" type="button" onClick={() => setProjectModal(true)} aria-label="Add a project"><Plus size={15} /></button></div>
            <div className="project-stack">{state.profile.projects.length ? state.profile.projects.map((project) => <article className="project-card" key={project.id}><div className="project-card-head"><h3>{project.name}</h3><button className="btn-icon mini-danger" type="button" onClick={() => removeProject(project.id)} aria-label={`Remove ${project.name}`}><Trash2 size={13} /></button></div><p>{project.description}</p><div className="card-skills">{project.tags.map((tag) => <span className="skill-pill match" key={tag}>{tag}</span>)}</div>{project.link && <span className="project-link"><ExternalLink size={11} />{project.link}</span>}</article>) : <EmptyState title="Add your first project" description="A class build, personal project or hackathon prototype all count." action={<button className="btn btn-outline btn-sm" type="button" onClick={() => setProjectModal(true)}>Add a project</button>} icon={<FolderKanban size={22} />} />}</div>
          </section>
          <section className="panel profile-tip-panel"><span className="tip-icon"><Lightbulb size={15} /></span><h3>Small details make a difference</h3><p>Projects with a short description and a few relevant skills make it easier for teams to see what you can do.</p><Link className="text-link" href="/achievements">Build your portfolio <ArrowRight /></Link></section>
        </div>
      </div>
      {projectModal && <Modal title="Add a project" description="Show a project, class build, research effort or hackathon prototype." onClose={() => setProjectModal(false)}><form onSubmit={handleProjectSubmit}><div className="form-field"><label className="field-label" htmlFor="project-name">Project name</label><input id="project-name" className="field-input" value={projectName} onChange={(event) => setProjectName(event.target.value)} required autoFocus /></div><div className="form-field"><label className="field-label" htmlFor="project-description">What did you make?</label><textarea id="project-description" className="field-textarea" value={projectDescription} onChange={(event) => setProjectDescription(event.target.value)} required /></div><div className="form-field"><label className="field-label" htmlFor="project-tags">Skills used (comma separated)</label><input id="project-tags" className="field-input" value={projectTags} onChange={(event) => setProjectTags(event.target.value)} placeholder="React, Python, Figma" /></div><div className="form-field"><label className="field-label" htmlFor="project-link">Project link (optional)</label><input id="project-link" className="field-input" value={projectLink} onChange={(event) => setProjectLink(event.target.value)} placeholder="github.com/you/project" /></div><div className="modal-actions"><button className="btn btn-ghost" type="button" onClick={() => setProjectModal(false)}>Cancel</button><button className="btn btn-primary" type="submit">Add to profile <Plus size={14} /></button></div></form></Modal>}
    </AppShell>
  );
}

export function ExplorePage() {
  const { state } = useDemo();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All opportunities");
  const [mode, setMode] = useState("All work modes");
  const [savedOnly, setSavedOnly] = useState(false);
  const [sortBy, setSortBy] = useState("Best match");
  const filtered = useMemo(() => {
    const search = query.trim().toLowerCase();
    let roles = state.internships.filter((internship) => {
      const textMatch = !search || `${internship.title} ${internship.company} ${internship.location} ${internship.skills.join(" ")} ${internship.category}`.toLowerCase().includes(search);
      return textMatch && (category === "All opportunities" || internship.category === category) && (mode === "All work modes" || internship.mode === mode) && (!savedOnly || state.savedInternships.includes(internship.id));
    });
    roles = [...roles].sort((left, right) => sortBy === "Newest" ? left.posted.localeCompare(right.posted) : sortBy === "Salary" ? right.salary.localeCompare(left.salary) : calculateMatch(right, state.profile, state.achievements) - calculateMatch(left, state.profile, state.achievements));
    return roles;
  }, [state.internships, state.savedInternships, state.profile, state.achievements, query, category, mode, savedOnly, sortBy]);

  return (
    <AppShell>
      <PageHeader title="Explore internships" description="Find your fit across teams that value what you can bring." action={<Link className="btn btn-outline btn-sm" href="/applications"><BriefcaseBusiness size={14} /> My applications</Link>} />
      <div className="explore-intro"><div className="explore-intro-icon"><Sparkles size={18} /></div><div><strong>Your best fit might be a skill you haven’t searched for yet.</strong><span>We’re showing roles ordered by how they match your profile.</span></div><Link className="text-link" href="/matches">How matching works <ArrowRight /></Link></div>
      <div className="panel explore-panel">
        <div className="toolbar"><div className="search-input-wrap"><Search /><input className="search-input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search job title, company, skill or location" aria-label="Search internships" /></div><select className="select-control" value={mode} onChange={(event) => setMode(event.target.value)} aria-label="Filter by work mode"><option>All work modes</option><option>Remote</option><option>Hybrid</option><option>On-site</option></select><select className="select-control" value={sortBy} onChange={(event) => setSortBy(event.target.value)} aria-label="Sort opportunities"><option>Best match</option><option>Newest</option><option>Salary</option></select><button className={`btn btn-sm ${savedOnly ? "btn-primary" : "btn-outline"}`} type="button" onClick={() => setSavedOnly((value) => !value)}><Heart size={13} fill={savedOnly ? "currentColor" : "none"} /> Saved {savedOnly ? "only" : "roles"}</button></div>
        <div className="category-tabs">{categories.map((item) => <button className={`category-tab${category === item ? " active" : ""}`} type="button" key={item} onClick={() => setCategory(item)}>{item}</button>)}</div>
      </div>
      <div className="results-meta"><span><strong>{filtered.length}</strong> opportunities to explore</span><span><Sparkles size={12} /> Match scores personalize as your profile grows</span></div>
      {filtered.length ? <div className="explore-grid">{filtered.map((internship) => <InternshipCard key={internship.id} internship={internship} quickApply />)}</div> : <EmptyState title="No opportunities found" description="Try a broader search, another work mode, or clear your saved-only filter." icon={<Search size={23} />} action={<button className="btn btn-outline btn-sm" type="button" onClick={() => { setQuery(""); setCategory("All opportunities"); setMode("All work modes"); setSavedOnly(false); }}>Clear filters</button>} />}
    </AppShell>
  );
}

export function InternshipDetailsPage({ id }: { id: string }) {
  const { state, toggleSaved, applyToInternship } = useDemo();
  const [feedback, setFeedback] = useState("");
  const internship = state.internships.find((item) => item.id === id);
  if (!internship) return <AppShell><EmptyState title="This opportunity has moved" description="It may have been removed from this demo. Explore all available roles instead." action={<Link className="btn btn-primary btn-sm" href="/explore">Explore internships</Link>} icon={<BriefcaseBusiness size={23} />} /></AppShell>;
  const score = calculateMatch(internship, state.profile, state.achievements);
  const overlap = getSkillOverlap(internship, state.profile.skills);
  const saved = state.savedInternships.includes(internship.id);
  const applied = state.applications.some((application) => application.internshipId === internship.id);
  const related = sortedMatches(state.internships.filter((item) => item.id !== internship.id), state.profile, state.achievements).slice(0, 2);

  function handleApply() {
    setFeedback(applyToInternship(id) ? "You’re on your way! This role is now in your application tracker." : "You’ve already applied. Your latest status is in the application tracker.");
  }

  return (
    <AppShell>
      <div className="breadcrumb"><Link href="/explore">Explore internships</Link><span>/</span><span>{internship.company}</span><ChevronRight /></div>
      <div className="detail-layout">
        <div className="detail-main">
          <section className="panel role-heading-panel">
            <div className="role-heading-top"><CompanyLogo internship={internship} /><div className="role-heading-copy"><span className="role-company">{internship.company}</span><h1>{internship.title}</h1><div className="role-meta"><span><MapPin />{internship.location}</span><span><BriefcaseBusiness />{internship.mode}</span><span><Clock3 />{internship.duration}</span></div></div><button className={`btn-icon detail-save${saved ? " active" : ""}`} type="button" onClick={() => toggleSaved(internship.id)} aria-label={saved ? "Remove from saved roles" : "Save role"}><Heart size={17} fill={saved ? "currentColor" : "none"} /></button></div>
            <div className="role-bottom-line"><MatchBadge score={score} /><span className="role-meta"><span><CircleDollarSign />{internship.salary}</span><span><CalendarDays />Posted {internship.posted}</span></span></div>
            {feedback && <Feedback>{feedback}</Feedback>}
            <div className="role-cta-row"><button className="btn btn-primary" type="button" onClick={handleApply}>{applied ? "You’ve applied" : "Apply for this internship"}{applied ? <Check size={15} /> : <ArrowRight size={15} />}</button>{applied && <Link className="btn btn-outline" href="/applications">View application status</Link>}<Link className="btn btn-ghost" href="/matches"><Sparkles size={14} /> Match analysis</Link></div>
          </section>
          <section className="panel detail-copy-panel"><div className="panel-heading"><div><h2>About the opportunity</h2><p>A chance to learn, contribute and make an impact.</p></div></div><p className="body-copy">{internship.description}</p><h3 className="subheading">What you’ll bring</h3><div className="detail-skill-list">{internship.skills.map((skill) => <span className={`detail-skill${overlap.matched.includes(skill) ? " detail-skill-match" : ""}`} key={skill}>{overlap.matched.includes(skill) && <Check size={12} />}{skill}</span>)}</div><div className="detail-highlight"><Sparkles size={16} /><div><strong>A good chance to grow</strong><p>{overlap.missing.length ? `You already bring ${overlap.matched.length} of ${internship.skills.length} key skills. ${overlap.missing.join(", ")} could be a great next learning step.` : "Your listed skills line up with each of this role’s core requirements."}</p></div></div><h3 className="subheading">Role details</h3><div className="detail-facts"><div><span>Work arrangement</span><strong>{internship.mode}</strong></div><div><span>Internship length</span><strong>{internship.duration}</strong></div><div><span>Compensation</span><strong>{internship.salary}</strong></div><div><span>Role category</span><strong>{internship.category}</strong></div></div></section>
        </div>
        <aside className="detail-side">
          <section className="panel match-explain-panel"><div className="match-score-large" style={{ "--progress": `${score}%` } as React.CSSProperties}><span><strong>{score}%</strong><small>match</small></span></div><h2>Your match, explained</h2><p>We compare your profile with the skills and focus of this role.</p><div className="mini-factor"><span>Required skills you have</span><strong>{overlap.matched.length}/{internship.skills.length}</strong></div><div className="progress-line"><span style={{ width: `${internship.skills.length ? overlap.matched.length / internship.skills.length * 100 : 0}%` }} /></div><div className="mini-factor"><span>Interest alignment</span><strong>{state.profile.interests.some((interest) => `${internship.category} ${internship.title}`.toLowerCase().includes(interest.toLowerCase().split(" ")[0])) ? "Strong" : "Good"}</strong></div><div className="mini-factor"><span>Project evidence</span><strong>{state.profile.projects.length} projects</strong></div><Link className="btn btn-outline btn-sm btn-full" href="/skills">Review skill gaps <ArrowRight size={13} /></Link></section>
          <section className="panel detail-company-panel"><div className="panel-heading"><div><h2>About {internship.company}</h2><p>Company profile</p></div><span className={`mini-company-logo logo-${internship.logoColor}`}>{internship.logo}</span></div><p>Meet a team that values curiosity, student voices and thoughtful collaboration. Explore an opportunity to learn from people who are excited to help early-career talent grow.</p><div className="company-mini-stats"><span><Building2 />Growing team</span><span><GraduationCap />Student-friendly</span></div></section>
          <div className="side-related"><div className="panel-heading"><div><h2>More roles you might like</h2></div></div>{related.map((item) => <div className="related-role" key={item.id}><CompanyLogo internship={item} small /><div><Link href={`/internships/${item.id}`}>{item.title}</Link><span>{item.company} · {calculateMatch(item, state.profile, state.achievements)}% match</span></div></div>)}</div>
        </aside>
      </div>
    </AppShell>
  );
}

export function MatchesPage() {
  const { state } = useDemo();
  const matches = sortedMatches(state.internships, state.profile, state.achievements);
  const [selectedId, setSelectedId] = useState("");
  const selected = state.internships.find((item) => item.id === selectedId) ?? matches[0];
  if (!state.internships.length) return <AppShell><EmptyState title="No active matches yet" description="Explore internships or add more detail to your profile to get started." action={<Link className="btn btn-primary btn-sm" href="/profile">Update my profile</Link>} /></AppShell>;
  const score = calculateMatch(selected, state.profile, state.achievements);
  const overlap = getSkillOverlap(selected, state.profile.skills);
  const interestCount = state.profile.interests.filter((interest) => `${selected.category} ${selected.title} ${selected.description}`.toLowerCase().includes(interest.toLowerCase().split(" ")[0])).length;
  const factors = [
    { label: "Skill alignment", value: Math.round(overlap.matched.length / Math.max(selected.skills.length, 1) * 100), note: `${overlap.matched.length} of ${selected.skills.length} role skills in your profile` },
    { label: "Interest alignment", value: interestCount ? 88 : 63, note: interestCount ? "This role connects with your chosen interests" : "A new area you could explore" },
    { label: "Project evidence", value: Math.min(96, 48 + state.profile.projects.length * 13), note: `${state.profile.projects.length} project${state.profile.projects.length === 1 ? "" : "s"} in your portfolio` },
    { label: "Achievement signal", value: Math.min(95, 45 + state.achievements.filter((item) => item.type === "Hackathon").length * 18), note: `${state.achievements.filter((item) => item.type === "Hackathon").length} hackathon result${state.achievements.filter((item) => item.type === "Hackathon").length === 1 ? "" : "s"} add context` },
  ];

  return (
    <AppShell>
      <PageHeader title="Your AI match analysis" description="A transparent look at how your profile connects with real opportunities." action={<Link className="btn btn-outline btn-sm" href="/profile"><GraduationCap size={14} /> Improve my profile</Link>} />
      <div className="match-analysis-layout">
        <section className="panel match-analysis-card">
          <div className="analysis-select-row"><div><span className="section-label">ANALYZE A ROLE</span><h2>See your potential, in context.</h2></div><select className="select-control" value={selected.id} onChange={(event) => setSelectedId(event.target.value)} aria-label="Select internship for analysis">{matches.map((internship) => <option value={internship.id} key={internship.id}>{internship.title} · {internship.company}</option>)}</select></div>
          <div className="selected-role-summary"><CompanyLogo internship={selected} /><div><h3>{selected.title}</h3><p>{selected.company} · {selected.location} · {selected.mode}</p></div><Link className="text-link" href={`/internships/${selected.id}`}>View role <ArrowRight /></Link></div>
          <div className="analysis-score-row"><div className="match-score-large analysis-ring" style={{ "--progress": `${score}%` } as React.CSSProperties}><span><strong>{score}%</strong><small>overall fit</small></span></div><div><span className="score-overline">A strong place to start</span><h3>{score >= 85 ? "Your profile stands out for this role." : score >= 70 ? "You have a solid foundation for this role." : "There’s room to grow into this opportunity."}</h3><p>Your score combines role skills, chosen interests, project evidence and achievements. It’s a guide—not a hiring decision.</p></div></div>
          <div className="panel-heading analysis-factors-heading"><div><h3>What shapes this match</h3><p>Each signal gives you a useful next step.</p></div><Link className="text-link" href="/skills">Find my gaps <ArrowRight /></Link></div>
          <div className="factor-list">{factors.map((factor) => <div className="factor-row" key={factor.label}><div className="factor-copy"><strong>{factor.label}</strong><span>{factor.note}</span></div><div className="factor-bar"><span style={{ width: `${factor.value}%` }} /></div><b>{factor.value}%</b></div>)}</div>
          <div className="analysis-reason"><Sparkles size={16} /><p><strong>Why you could be a fit:</strong> Your {overlap.matched.slice(0, 2).join(" and ") || "existing skills"} experience and hands-on project work give you a useful foundation. {overlap.missing.length ? `Build confidence in ${overlap.missing[0]} as a next step.` : "Your skills already cover the core requirements listed."}</p></div>
        </section>
        <aside className="match-analysis-side"><section className="panel"><div className="panel-heading"><div><h2>Skill overlap</h2><p>What you have—and what you can learn</p></div></div><div className="card-skills match-skill-list">{overlap.matched.map((skill) => <span className="skill-pill match" key={skill}><Check size={10} />{skill}</span>)}{overlap.missing.map((skill) => <span className="skill-pill missing" key={skill}>{skill}</span>)}</div><div className="legend-line"><span className="legend-dot match-dot" /> In your profile <span className="legend-dot missing-dot" /> Growth opportunity</div><Link className="text-link" href="/skills">Build a skill plan <ArrowRight /></Link></section><section className="analysis-next-step"><span><Lightbulb size={16} /></span><h3>Match scores move with you.</h3><p>Add a new project, skill or hackathon result to see your fit update instantly.</p><Link href="/achievements">Add an achievement <ArrowRight size={12} /></Link></section></aside>
      </div>
      <section style={{ marginTop: 20 }}><div className="panel-heading"><div><h2 className="section-title-small">More roles that fit your profile</h2><p>Personalized from your skills and interests</p></div><Link className="text-link" href="/explore">Explore all <ArrowRight /></Link></div><div className="recommend-grid">{matches.slice(0, 3).map((item) => <InternshipCard key={item.id} internship={item} />)}</div></section>
    </AppShell>
  );
}

export function SkillGapPage() {
  const { state, addLearningGoal } = useDemo();
  const matches = sortedMatches(state.internships, state.profile, state.achievements);
  const [selectedId, setSelectedId] = useState("");
  const selected = state.internships.find((item) => item.id === selectedId) ?? matches[0];
  const [notice, setNotice] = useState("");
  if (!selected) return <AppShell><EmptyState title="No roles to analyze" description="Explore the opportunity list first, then return to compare your skills." action={<Link className="btn btn-primary btn-sm" href="/explore">Explore roles</Link>} /></AppShell>;
  const overlap = getSkillOverlap(selected, state.profile.skills);
  const learning = overlap.missing.filter((skill) => state.learningGoals.includes(skill));
  const toLearn = overlap.missing.filter((skill) => !state.learningGoals.includes(skill));

  function saveLearningPlan() {
    toLearn.forEach(addLearningGoal);
    setNotice(toLearn.length ? `${toLearn.length} skill${toLearn.length === 1 ? "" : "s"} added to your learning goals.` : "These skills are already in your learning goals.");
  }

  return (
    <AppShell>
      <PageHeader title="Skill gap analyzer" description="See the skills you already bring—and choose an approachable next step." action={<Link className="btn btn-outline btn-sm" href="/roadmap"><Map size={14} /> View my roadmap</Link>} />
      <div className="gap-hero"><div><span className="section-label">A GROWTH PLAN, NOT A CHECKLIST</span><h3>Every role is a chance to learn something new.</h3><p>Choose an opportunity to compare its requirements with the skills you’ve added to your profile.</p></div><div className="gap-count"><span>{overlap.missing.length}</span></div></div>
      <div className="gap-toolbar panel"><div className="gap-role-label"><CompanyLogo internship={selected} small /><div><span>COMPARE MY PROFILE TO</span><strong>{selected.title}</strong></div></div><select className="select-control" value={selected.id} onChange={(event) => { setSelectedId(event.target.value); setNotice(""); }} aria-label="Select role for skill comparison">{matches.map((internship) => <option key={internship.id} value={internship.id}>{internship.title} · {internship.company}</option>)}</select></div>
      <div className="two-column skill-analysis-columns">
        <section className="panel"><div className="panel-heading"><div><h2>Your skill map</h2><p>{overlap.matched.length} aligned skills and {overlap.missing.length} growth opportunities</p></div><span className="match-badge"><Sparkles />{calculateMatch(selected, state.profile, state.achievements)}% fit</span></div>
          {selected.skills.map((skill) => { const hasSkill = overlap.matched.includes(skill); const planned = state.learningGoals.includes(skill); return <div className="skill-row" key={skill}><div className="skill-row-label"><i className={`skill-dot${hasSkill ? "" : " missing"}`} /><strong>{skill}</strong></div><div className="skill-row-track"><span className={hasSkill ? "" : "growth"} style={{ width: hasSkill ? "100%" : planned ? "52%" : "25%" }} /></div><span className={`skill-row-tail${hasSkill ? " skill-confirmed" : ""}`}>{hasSkill ? "In profile" : planned ? "Learning goal" : "Explore next"}</span></div>; })}
          <div className="skill-map-legend"><span><i className="skill-dot" />Already in your profile</span><span><i className="skill-dot missing" />Potential growth area</span></div>
        </section>
        <div className="side-stack"><section className="panel"><div className="panel-heading"><div><h2>Your learning goals</h2><p>Small steps worth exploring</p></div><span className="goal-count">{state.learningGoals.length}</span></div>{state.learningGoals.length ? <div className="learning-goals-list">{state.learningGoals.map((skill) => <div className="learning-goal-row" key={skill}><span><BookOpen size={14} /></span><strong>{skill}</strong><CheckCircle2 size={14} color="#31a57b" /></div>)}</div> : <div className="compact-empty"><Lightbulb size={17} /><span>As you discover new areas, add a skill here to keep your learning plan close.</span></div>}{toLearn.length > 0 && <button className="btn btn-primary btn-full" type="button" onClick={saveLearningPlan}><Plus size={14} />Add {toLearn.length} skill{toLearn.length === 1 ? "" : "s"} to my learning goals</button>}{notice && <Feedback>{notice}</Feedback>}</section><section className="panel learning-resources"><div className="panel-heading"><div><h2>A helpful next step</h2><p>Pick a path that feels manageable</p></div></div><div className="resource-step"><span>01</span><div><strong>Learn the basics</strong><p>Find a short tutorial or guided project.</p></div></div><div className="resource-step"><span>02</span><div><strong>Make something small</strong><p>Practice by building a tiny, real example.</p></div></div><div className="resource-step"><span>03</span><div><strong>Show your learning</strong><p>Add your project and new skills to your profile.</p></div></div><Link className="text-link" href="/profile">Update my skills <ArrowRight /></Link></section></div>
      </div>
    </AppShell>
  );
}

function buildResumeSample(profile: Profile) {
  return `${profile.name}\n${profile.major} student · ${profile.school}\n\nSUMMARY\n${profile.bio}\n\nSKILLS\n${profile.skills.join(" · ")}\n\nPROJECTS\n${profile.projects.map((project) => `${project.name}: ${project.description} (${project.tags.join(", ")})`).join("\n")}\n\nACHIEVEMENTS\n${profile.certifications.join(" · ")}`;
}

export function ResumeAnalyzerPage() {
  const { state } = useDemo();
  const [selectedId, setSelectedId] = useState("");
  const [resumeText, setResumeText] = useState("");
  const [analyzed, setAnalyzed] = useState(false);
  const [resumeResult, setResumeResult] = useState<{ score: number; matched: string[]; missing: string[]; profileHits: string[] } | null>(null);
  const [fileName, setFileName] = useState("");
  const [feedback, setFeedback] = useState("");
  const roles = sortedMatches(state.internships, state.profile, state.achievements);
  const selected = state.internships.find((item) => item.id === selectedId) ?? roles[0];

  useEffect(() => { if (!resumeText) setResumeText(buildResumeSample(state.profile)); }, [resumeText, state.profile]);

  function analyzeResume() {
    if (!selected || !resumeText.trim()) { setFeedback("Add or paste some résumé text before analyzing."); return; }
    const normalizedText = resumeText.toLowerCase();
    const matched = selected.skills.filter((skill) => normalizedText.includes(skill.toLowerCase()));
    const missing = selected.skills.filter((skill) => !normalizedText.includes(skill.toLowerCase()));
    const profileHits = state.profile.skills.filter((skill) => normalizedText.includes(skill.toLowerCase()));
    const score = Math.min(98, Math.round(52 + (matched.length / Math.max(selected.skills.length, 1)) * 36 + Math.min(profileHits.length, 5) * 2));
    setResumeResult({ score, matched, missing, profileHits });
    setAnalyzed(true);
    setFeedback(`Your résumé has been reviewed for ${selected.title}.`);
  }

  async function handleFile(file?: File) {
    if (!file) return;
    setFileName(file.name);
    if (file.type === "text/plain" || file.name.toLowerCase().endsWith(".txt")) {
      setResumeText(await file.text());
      setFeedback("Text file loaded. Choose a role and analyze when you’re ready.");
    } else {
      setResumeText(buildResumeSample(state.profile));
      setFeedback("PDF selected. This local demo compares your saved profile details—no file leaves your device.");
    }
    setAnalyzed(false);
    setResumeResult(null);
  }

  return (
    <AppShell>
      <PageHeader title="Resume analyzer" description="Get quick, local feedback on how your experience connects to a specific role." action={<Link className="btn btn-outline btn-sm" href="/profile"><FileText size={14} /> Update my profile</Link>} />
      <div className="resume-layout">
        <div className="side-stack"><section className="panel"><div className="panel-heading"><div><h2>Choose a role to target</h2><p>We’ll look for relevant skills in your résumé text.</p></div></div><select className="field-select" value={selected?.id ?? ""} onChange={(event) => { setSelectedId(event.target.value); setAnalyzed(false); }} aria-label="Choose a role for resume analysis">{roles.map((role) => <option value={role.id} key={role.id}>{role.title} · {role.company}</option>)}</select><div className="resume-role-note">{selected && <><CompanyLogo internship={selected} small /><span><strong>{selected.title}</strong><small>{selected.skills.length} core skills considered</small></span></>}</div></section><section className="panel"><div className="panel-heading"><div><h2>Add your résumé</h2><p>Paste your résumé text or load a local document.</p></div></div><label className="file-drop" htmlFor="resume-upload"><Upload size={20} /><strong>{fileName || "Choose a résumé file"}</strong><span>PDF or plain text · stays in your browser</span><input id="resume-upload" type="file" accept=".pdf,.txt,application/pdf,text/plain" onChange={(event) => { void handleFile(event.target.files?.[0]); }} /></label><div className="resume-local-note"><CheckCircle2 size={13} />Your résumé is analyzed locally and never uploaded.</div></section></div>
        <section className="panel resume-text-panel"><div className="panel-heading"><div><h2>Review résumé text</h2><p>You can edit this demo résumé before analysis.</p></div><span className="pill">{resumeText.length} characters</span></div><textarea className="resume-textarea" value={resumeText} onChange={(event) => { setResumeText(event.target.value); setAnalyzed(false); setResumeResult(null); }} aria-label="Resume text to analyze" placeholder="Paste your résumé text here…" /><div className="resume-action-row"><span>Try a role-specific analysis in seconds.</span><button className="btn btn-primary" type="button" onClick={analyzeResume}><Sparkles size={14} />Analyze résumé</button></div>{feedback && <Feedback>{feedback}</Feedback>}</section>
      </div>
      {analyzed && resumeResult && selected && <section className="panel resume-results"><div className="panel-heading"><div><h2>Your role-specific snapshot</h2><p>{selected.title} · {selected.company}</p></div><span className="status-pill Offer">Analysis complete</span></div><div className="resume-result-top"><div className="resume-score-wrap"><div className="resume-score-ring" style={{ "--progress": `${resumeResult.score}%` } as React.CSSProperties}><strong>{resumeResult.score}</strong></div><div className="resume-score-copy"><h3>{resumeResult.score >= 82 ? "A promising foundation" : "Good starting point"}</h3><p>This is a local skills comparison—not a hiring decision. Make sure your résumé shows your impact, not just your tools.</p></div></div><Link className="btn btn-outline btn-sm" href="/matches">Compare match score <ArrowRight size={13} /></Link></div><div className="resume-findings"><div className="finding-card"><strong><CheckCircle2 size={12} color="#299d76" /> Skills clearly mentioned</strong><div className="card-skills">{resumeResult.matched.length ? resumeResult.matched.map((skill) => <span className="skill-pill success" key={skill}>{skill}</span>) : <span className="finding-empty">Add a role skill you’ve used.</span>}</div></div><div className="finding-card"><strong><Lightbulb size={12} color="#d09042" /> Skills to highlight or learn</strong><div className="card-skills">{resumeResult.missing.length ? resumeResult.missing.map((skill) => <span className="skill-pill missing" key={skill}>{skill}</span>) : <span className="finding-empty">All key role skills are represented.</span>}</div></div></div><div className="resume-tips"><h3>Thoughtful improvements</h3><ul><li>Lead project bullets with what changed because of your work.</li><li>Where it’s true, add numbers to show scale, reach or time saved.</li><li>Use the role’s language naturally when describing a skill you’ve actually practiced.</li></ul><Link className="text-link" href="/skills">Explore a skill gap plan <ArrowRight /></Link></div></section>}
    </AppShell>
  );
}

export function ApplicationsPage() {
  const { state, updateApplicationStatus, removeApplication } = useDemo();
  const [filter, setFilter] = useState("All applications");
  const statuses: (ApplicationStatus | "All applications")[] = ["All applications", "Applied", "In review", "Interview", "Offer", "Not selected"];
  const filtered = state.applications.filter((application) => filter === "All applications" || application.status === filter);
  const counts = {
    all: state.applications.length,
    interviews: state.applications.filter((application) => application.status === "Interview").length,
    offers: state.applications.filter((application) => application.status === "Offer").length,
  };

  return (
    <AppShell>
      <PageHeader title="Application tracker" description="Every application, one clear next step at a time." action={<Link className="btn btn-primary btn-sm" href="/explore"><Plus size={14} /> Find a new role</Link>} />
      <section className="stats-grid tracker-stats"><StatCard title="Applications sent" value={counts.all} hint="Your recent momentum" icon={<BriefcaseBusiness />} /><StatCard title="Interview stage" value={counts.interviews} hint="A conversation is progress" tone="blue" icon={<CalendarDays />} /><StatCard title="Offers" value={counts.offers} hint="Here’s to your next step" tone="green" icon={<Trophy />} /><StatCard title="Saved for later" value={state.savedInternships.length} hint="Roles to revisit when ready" tone="orange" icon={<Heart />} /></section>
      <section className="panel tracker-panel"><div className="tracker-toolbar"><div className="category-tabs">{statuses.map((status) => <button className={`category-tab${filter === status ? " active" : ""}`} type="button" onClick={() => setFilter(status)} key={status}>{status}{status === "All applications" && <span className="filter-count">{state.applications.length}</span>}</button>)}</div><span className="tracker-caption"><Filter size={12} /> Status updates are saved in this browser</span></div>
        {filtered.length ? <div className="application-list tracker-list">{filtered.map((application) => {
          const internship = state.internships.find((item) => item.id === application.internshipId);
          if (!internship) return null;
          return <article className="application-row tracker-row" key={application.id}><div className="application-company"><CompanyLogo internship={internship} small /><div><h3><Link href={`/internships/${internship.id}`}>{internship.title}</Link></h3><p>{internship.company} · {internship.location}</p></div></div><div className="application-meta"><small>Submitted</small><span>{formatDate(application.appliedAt)}</span></div><div className="application-status-control"><label className="field-label" htmlFor={`status-${application.id}`}>Current status</label><select className={`status-select status-${application.status.replaceAll(" ", "-")}`} id={`status-${application.id}`} value={application.status} onChange={(event) => updateApplicationStatus(application.id, event.target.value as ApplicationStatus)} aria-label={`Change status for ${internship.title}`}>{statuses.slice(1).map((status) => <option key={status} value={status}>{status}</option>)}</select></div><div className="tracker-actions"><Link className="btn-icon" href={`/internships/${internship.id}`} aria-label={`View ${internship.title}`}><ExternalLink size={14} /></Link><button className="btn-icon mini-danger" type="button" onClick={() => { if (window.confirm("Remove this application from your demo tracker?")) removeApplication(application.id); }} aria-label={`Remove ${internship.title} application`} title="Remove from tracker"><Trash2 size={14} /></button></div></article>;
        })}</div> : <EmptyState title={filter === "All applications" ? "Your story is still unfolding" : `No ${filter.toLowerCase()} applications`} description={filter === "All applications" ? "Explore a role and apply when you’re ready. Your application will appear here." : "Choose another status filter or explore new roles."} action={<Link className="btn btn-primary btn-sm" href="/explore">Explore internships</Link>} icon={<BriefcaseBusiness size={23} />} />}
      </section>
      <section className="tracker-footer-note"><span><Lightbulb size={15} /></span><p><strong>One thoughtful follow-up can help.</strong> Add a calendar reminder after applying, and take a moment to thank an interviewer after each conversation.</p><Link className="text-link" href="/roadmap">See my roadmap <ArrowRight /></Link></section>
    </AppShell>
  );
}

const roadmapSteps = [
  { id: "profile", title: "Make your strengths easy to find", description: "Complete your profile with skills, interests and the kind of problems you love solving.", category: "PROFILE", href: "/profile", action: "Review profile" },
  { id: "resume", title: "Tell a clear story with your résumé", description: "Use real examples and show the result of your work. Tailor your skills to each role honestly.", category: "PREPARE", href: "/resume", action: "Analyze résumé" },
  { id: "portfolio", title: "Show the work behind your skills", description: "Add a class project, a hackathon prototype or something you built just to learn.", category: "PORTFOLIO", href: "/achievements", action: "Build portfolio" },
  { id: "skills", title: "Choose one skill to grow next", description: "Turn a role’s skill gap into a low-pressure learning goal and a small practice project.", category: "GROW", href: "/skills", action: "Find a skill gap" },
  { id: "explore", title: "Find a role worth your time", description: "Compare opportunities based on your interests, projects and skills—not just a title.", category: "EXPLORE", href: "/explore", action: "Explore roles" },
  { id: "apply", title: "Apply with intention", description: "Choose a good-fit role, personalize your application and keep the next step on your tracker.", category: "TAKE ACTION", href: "/applications", action: "Open tracker" },
];

export function CareerRoadmapPage() {
  const { state, toggleRoadmapStep } = useDemo();
  const completedCount = state.completedRoadmapSteps.length;
  const progress = Math.round(completedCount / roadmapSteps.length * 100);

  return (
    <AppShell>
      <PageHeader title="Your career roadmap" description="A flexible guide to turn what you want next into steps you can take today." action={<Link className="btn btn-outline btn-sm" href="/matches"><Sparkles size={14} /> View my matches</Link>} />
      <section className="roadmap-summary panel"><div className="roadmap-summary-icon"><Map size={19} /></div><div className="roadmap-summary-copy"><span>YOUR JOURNEY · BUILT AROUND YOU</span><h2>Progress is a direction, not a deadline.</h2><p>Finish one small action at a time. Your roadmap remembers where you left off.</p></div><div className="roadmap-progress-number"><strong>{progress}%</strong><span>{completedCount} of {roadmapSteps.length} steps</span></div></section>
      <div className="roadmap-progress-bar"><span style={{ width: `${progress}%` }} /></div>
      <div className="roadmap-layout"><section className="panel"><div className="panel-heading"><div><h2>Your next steps</h2><p>Recommended from your profile and saved progress</p></div><span className="pill">{roadmapSteps.length - completedCount} left to explore</span></div><div className="roadmap-list">{roadmapSteps.map((step, index) => { const done = state.completedRoadmapSteps.includes(step.id); return <article className={`roadmap-item${done ? " roadmap-item-done" : ""}`} key={step.id}><button className={`roadmap-marker${done ? " done" : ""}`} type="button" onClick={() => toggleRoadmapStep(step.id)} aria-label={done ? `Mark ${step.title} incomplete` : `Mark ${step.title} complete`}>{done ? <Check size={15} /> : <span>{String(index + 1).padStart(2, "0")}</span>}</button><div className="roadmap-copy"><span className="roadmap-category">{step.category}</span><h3>{step.title}</h3><p>{step.description}</p><Link className="text-link roadmap-action" href={step.href}>{step.action} <ArrowRight /></Link></div><button className={`roadmap-done-action${done ? " complete" : ""}`} type="button" onClick={() => toggleRoadmapStep(step.id)}>{done ? <><Check size={12} /> Done</> : "Mark done"}</button></article>; })}</div></section>
        <aside className="side-stack"><section className="panel"><div className="panel-heading"><div><h2>Suggested for you</h2><p>Small actions, real momentum</p></div></div><div className="suggested-action"><span><Target size={15} /></span><div><strong>Add one more project</strong><p>Show how you put a skill into practice.</p><Link href="/profile">Add a project <ArrowRight size={11} /></Link></div></div><div className="suggested-action"><span><Award size={15} /></span><div><strong>Share a hackathon win</strong><p>Competition work can show initiative.</p><Link href="/achievements">Add an achievement <ArrowRight size={11} /></Link></div></div><div className="suggested-action"><span><Heart size={15} /></span><div><strong>Save a good-fit role</strong><p>Keep the roles you like close by.</p><Link href="/explore">Explore internships <ArrowRight size={11} /></Link></div></div></section><section className="roadmap-encouragement"><Sparkles size={18} /><h3>Your path doesn’t have to look like anyone else’s.</h3><p>Try, learn, adjust. Each project and conversation makes your next step clearer.</p></section></aside>
      </div>
    </AppShell>
  );
}

export function AchievementsPage() {
  const { state, addProject, removeProject, addAchievement } = useDemo();
  const [projectModal, setProjectModal] = useState(false);
  const [achievementModal, setAchievementModal] = useState(false);
  const [projectName, setProjectName] = useState("");
  const [projectDescription, setProjectDescription] = useState("");
  const [projectTags, setProjectTags] = useState("");
  const [eventName, setEventName] = useState("");
  const [achievementTitle, setAchievementTitle] = useState("");
  const [achievementDetail, setAchievementDetail] = useState("");
  const [achievementDate, setAchievementDate] = useState("");
  const [achievementType, setAchievementType] = useState<Achievement["type"]>("Hackathon");
  const [notice, setNotice] = useState("");

  function submitProject(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    addProject({ name: projectName.trim(), description: projectDescription.trim(), tags: projectTags.split(",").map((item) => item.trim()).filter(Boolean) });
    setProjectName(""); setProjectDescription(""); setProjectTags(""); setProjectModal(false); setNotice("Project added to your portfolio.");
  }

  function submitAchievement(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    addAchievement({ title: achievementTitle.trim(), event: eventName.trim(), detail: achievementDetail.trim(), date: achievementDate || "Recently", type: achievementType });
    setEventName(""); setAchievementTitle(""); setAchievementDetail(""); setAchievementDate(""); setAchievementModal(false); setNotice("Achievement added to your portfolio.");
  }

  const hackathonCount = state.achievements.filter((item) => item.type === "Hackathon").length;
  const winsCount = state.achievements.filter((item) => item.type === "Award").length;

  return (
    <AppShell>
      <PageHeader title="Achievements & portfolio" description="Show the projects, competitions and skills behind your potential." action={<div className="portfolio-actions"><button className="btn btn-outline btn-sm" type="button" onClick={() => setProjectModal(true)}><Plus size={13} /> Add project</button><button className="btn btn-primary btn-sm" type="button" onClick={() => setAchievementModal(true)}><Trophy size={13} /> Add achievement</button></div>} />
      <div className="portfolio-banner"><div className="portfolio-banner-mark"><Trophy size={20} /></div><div><span>YOUR STORY, IN BUILT FORM</span><h2>Every project is proof of what you can do.</h2><p>Share the work, teamwork and curiosity behind the skills on your profile.</p></div><Link className="btn btn-white btn-sm" href="/profile">Edit profile <ArrowRight size={13} /></Link></div>
      <section className="stats-grid portfolio-stats"><StatCard title="Projects" value={state.profile.projects.length} hint="Builds, experiments and ideas" icon={<FolderKanban />} /><StatCard title="Hackathons" value={hackathonCount} hint="A little proof of your initiative" tone="orange" icon={<Trophy />} /><StatCard title="Awards & wins" value={winsCount} hint="Your work, recognized" tone="green" icon={<Award />} /><StatCard title="Certifications" value={state.profile.certifications.length + state.achievements.filter((item) => item.type === "Certification").length} hint="Skills you’ve worked to validate" tone="blue" icon={<BadgeCheck />} /></section>
      {notice && <Feedback>{notice}</Feedback>}
      <div className="portfolio-layout">
        <section className="panel"><div className="panel-heading"><div><h2>Projects & builds</h2><p>The work you’ve learned by doing</p></div><button className="btn-icon" type="button" onClick={() => setProjectModal(true)} aria-label="Add project"><Plus size={15} /></button></div>{state.profile.projects.length ? <div className="portfolio-projects">{state.profile.projects.map((project, index) => <article className="portfolio-project" key={project.id}><div className="portfolio-project-index">{String(index + 1).padStart(2, "0")}</div><div className="portfolio-project-body"><div className="project-card-head"><h3>{project.name}</h3><button className="btn-icon mini-danger" type="button" onClick={() => removeProject(project.id)} title="Remove project" aria-label={`Remove ${project.name}`}><Trash2 size={13} /></button></div><p>{project.description}</p><div className="card-skills">{project.tags.map((tag) => <span className="skill-pill match" key={tag}>{tag}</span>)}</div>{project.link && <span className="project-link"><ExternalLink size={11} />{project.link}</span>}</div></article>)}</div> : <EmptyState title="There’s room for your first project" description="A class build, personal project or hackathon prototype can all show your initiative." action={<button className="btn btn-primary btn-sm" type="button" onClick={() => setProjectModal(true)}>Add a project <Plus size={12} /></button>} icon={<FolderKanban size={22} />} />}</section>
        <section className="panel"><div className="panel-heading"><div><h2>Hackathons & achievements</h2><p>Your work in a team and under a deadline</p></div><button className="btn-icon" type="button" onClick={() => setAchievementModal(true)} aria-label="Add achievement"><Plus size={15} /></button></div>{state.achievements.length ? <div className="achievement-stack">{state.achievements.map((achievement) => <article className="achievement-card" key={achievement.id}><span className={`achievement-icon${achievement.type === "Certification" ? " cert" : ""}`}>{achievement.type === "Certification" ? <BadgeCheck size={17} /> : achievement.type === "Hackathon" ? <Trophy size={17} /> : <Award size={17} />}</span><div><span className="achievement-type-label">{achievement.type}</span><h3>{achievement.title}</h3><p>{achievement.event} · {achievement.detail}</p><small>{achievement.date}</small></div></article>)}</div> : <EmptyState title="Your next achievement starts here" description="Add a hackathon, certification or award you’re proud of." action={<button className="btn btn-outline btn-sm" type="button" onClick={() => setAchievementModal(true)}>Add achievement</button>} icon={<Award size={22} />} />}</section>
      </div>
      <section className="portfolio-certifications panel"><div className="panel-heading"><div><h2>Certifications & learning</h2><p>Knowledge you’ve invested in</p></div><Link className="text-link" href="/profile">Manage profile <ArrowRight /></Link></div><div className="certification-list">{[...state.profile.certifications.map((title) => ({ title, source: "Profile certification" })), ...state.achievements.filter((item) => item.type === "Certification").map((item) => ({ title: item.title, source: item.event }))].map((cert, index) => <div className="certification-item" key={`${cert.title}-${index}`}><span><BadgeCheck size={15} /></span><div><strong>{cert.title}</strong><small>{cert.source}</small></div><CheckCircle2 size={15} color="#38a47e" /></div>)}</div></section>
      {projectModal && <Modal title="Add a project" description="Share something you built, researched or made better." onClose={() => setProjectModal(false)}><form onSubmit={submitProject}><div className="form-field"><label className="field-label" htmlFor="portfolio-project-name">Project name</label><input id="portfolio-project-name" className="field-input" value={projectName} onChange={(event) => setProjectName(event.target.value)} required /></div><div className="form-field"><label className="field-label" htmlFor="portfolio-project-description">What did you do?</label><textarea id="portfolio-project-description" className="field-textarea" value={projectDescription} onChange={(event) => setProjectDescription(event.target.value)} required /></div><div className="form-field"><label className="field-label" htmlFor="portfolio-project-skills">Skills used (comma separated)</label><input id="portfolio-project-skills" className="field-input" value={projectTags} onChange={(event) => setProjectTags(event.target.value)} placeholder="React, Python, teamwork" /></div><div className="modal-actions"><button type="button" className="btn btn-ghost" onClick={() => setProjectModal(false)}>Cancel</button><button type="submit" className="btn btn-primary">Add project <Plus size={13} /></button></div></form></Modal>}
      {achievementModal && <Modal title="Add an achievement" description="A hackathon result, award or certification—all the details that make it yours." onClose={() => setAchievementModal(false)}><form onSubmit={submitAchievement}><div className="form-field"><label className="field-label" htmlFor="achievement-type">Achievement type</label><select id="achievement-type" className="field-select" value={achievementType} onChange={(event) => setAchievementType(event.target.value as Achievement["type"])}><option>Hackathon</option><option>Certification</option><option>Award</option></select></div><div className="form-field"><label className="field-label" htmlFor="achievement-title">Result or credential</label><input id="achievement-title" className="field-input" value={achievementTitle} onChange={(event) => setAchievementTitle(event.target.value)} required placeholder="e.g. Best Use of AI" /></div><div className="form-field"><label className="field-label" htmlFor="achievement-event">Event or organization</label><input id="achievement-event" className="field-input" value={eventName} onChange={(event) => setEventName(event.target.value)} required placeholder="e.g. Cal Hacks" /></div><div className="form-field"><label className="field-label" htmlFor="achievement-detail">A few words about it</label><textarea id="achievement-detail" className="field-textarea" value={achievementDetail} onChange={(event) => setAchievementDetail(event.target.value)} placeholder="What did you build or learn?" /></div><div className="form-field"><label className="field-label" htmlFor="achievement-date">When?</label><input id="achievement-date" className="field-input" value={achievementDate} onChange={(event) => setAchievementDate(event.target.value)} placeholder="e.g. Nov 2025" /></div><div className="modal-actions"><button type="button" className="btn btn-ghost" onClick={() => setAchievementModal(false)}>Cancel</button><button type="submit" className="btn btn-primary">Add achievement <Trophy size={13} /></button></div></form></Modal>}
    </AppShell>
  );
}
