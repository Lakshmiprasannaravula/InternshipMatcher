"use client";

import { useMemo, useState, type FormEvent } from "react";
import Link from "next/link";
import {
  ArrowDownUp,
  ArrowRight,
  Award,
  BriefcaseBusiness,
  Building2,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleDollarSign,
  Download,
  ExternalLink,
  FilePlus2,
  Filter,
  Heart,
  MapPin,
  Plus,
  Search,
  Sparkles,
  Target,
  Trash2,
  TrendingUp,
  Users,
  X,
} from "lucide-react";
import { candidates, calculateMatch, type Candidate, type Internship } from "@/lib/data";
import { useDemo } from "@/lib/demo-store";
import { AppShell, CompanyLogo, EmptyState, Feedback, Modal, PageHeader, StatCard } from "@/components/common";

function recruiterMatch(candidate: Candidate, internship: Internship) {
  const skills = new Set(candidate.skills.map((skill) => skill.toLowerCase()));
  const overlap = internship.skills.filter((skill) => skills.has(skill.toLowerCase())).length;
  const score = 47 + overlap / Math.max(1, internship.skills.length) * 34 + Math.min(candidate.projects, 5) * 2 + Math.min(candidate.hackathons, 4) * 2 + Math.min(candidate.certifications.length, 2);
  return Math.min(99, Math.round(score));
}

function initials(name: string) {
  return name.split(" ").filter(Boolean).slice(0, 2).map((part) => part[0]?.toUpperCase()).join("");
}

function titleLogo(company: string) {
  return company.trim().slice(0, 1).toUpperCase() || "I";
}

export function AdminDashboard() {
  const { state } = useDemo();
  const role = state.internships.find((item) => item.id === "python-developer") ?? state.internships[0];
  const shortlist = candidates.filter((candidate) => state.shortlistedCandidates.includes(candidate.id));
  const topCandidates = role ? [...candidates].sort((left, right) => recruiterMatch(right, role) - recruiterMatch(left, role)).slice(0, 4) : candidates.slice(0, 4);
  const average = Math.round(candidates.reduce((total, candidate) => total + (role ? recruiterMatch(candidate, role) : candidate.match), 0) / Math.max(candidates.length, 1));

  return (
    <AppShell admin>
      <div className="admin-welcome"><div><span className="admin-eyebrow">TALENT WORKSPACE · TUESDAY, FEBRUARY 17</span><h1>Make a match that matters.</h1><p>Explore the students, work and potential behind your next great hire.</p></div><Link className="btn btn-white btn-sm" href="/admin/candidates"><Users size={14} />Discover candidates <ArrowRight size={13} /></Link></div>
      <PageHeader title="Recruiter overview" description="A live look at opportunities, emerging talent and your shortlist." action={<Link className="btn btn-outline btn-sm" href="/admin/internships"><BriefcaseBusiness size={14} /> Manage roles</Link>} />
      <section className="stats-grid admin-stats"><StatCard title="Student candidates" value={candidates.length} hint="Curated demo student profiles" icon={<Users />} /><StatCard title="Open internships" value={state.internships.length} hint="Active roles in your workspace" tone="blue" icon={<BriefcaseBusiness />} /><StatCard title="Shortlisted" value={shortlist.length} hint="Candidates for a closer look" tone="green" icon={<Heart />} /><StatCard title="Average role fit" value={`${average}%`} hint="Based on skills and portfolio signals" tone="orange" icon={<TrendingUp />} /></section>
      <div className="admin-dashboard-grid">
        <section className="panel"><div className="panel-heading"><div><h2>High-potential candidates</h2><p>Recommended for the Python Developer Intern role</p></div><Link className="text-link" href="/admin/candidates">Browse talent <ArrowRight /></Link></div><div className="top-candidate-list">{topCandidates.map((candidate, index) => { const score = role ? recruiterMatch(candidate, role) : candidate.match; return <article className="admin-candidate-row" key={candidate.id}><span className={`candidate-rank${index === 0 ? " rank-top" : ""}`}>{String(index + 1).padStart(2, "0")}</span><span className={`avatar ${["", "blue", "green", "orange", "pink"][index % 5]}`}>{candidate.initials}</span><div className="candidate-main-copy"><strong>{candidate.name}</strong><span>{candidate.major} · {candidate.school}</span><div className="card-skills">{candidate.skills.slice(0, 3).map((skill) => <span className="skill-pill" key={skill}>{skill}</span>)}</div></div><div className="candidate-match-detail"><strong>{score}%</strong><span>match</span></div><Link className="btn-icon" href="/admin/candidates" aria-label={`View ${candidate.name}`}><ChevronRight size={14} /></Link></article>; })}</div></section>
        <section className="panel talent-insight-panel"><div className="panel-heading"><div><h2>Your role, in focus</h2><p>{role?.title ?? "Explore student talent"}</p></div><span className="admin-insight-icon"><Sparkles size={16} /></span></div><div className="insight-chart"><div className="insight-chart-top"><span>Candidate fit distribution</span><strong>+18% <small>vs. all roles</small></strong></div><div className="chart-bars">{[68, 84, 55, 95, 72, 88, 61, 78, 98, 72, 87, 66].map((height, index) => <i key={index} style={{ height: `${height}%` }} />)}</div><div className="chart-axis"><span>Emerging</span><span>Strong fit</span><span>Exceptional</span></div></div><div className="insight-quick-stats"><div><strong>{candidates.filter((candidate) => role && recruiterMatch(candidate, role) >= 85).length}</strong><span>strong fits</span></div><div><strong>{candidates.filter((candidate) => candidate.hackathons > 0).length}</strong><span>hackathon builders</span></div><div><strong>{candidates.reduce((sum, candidate) => sum + candidate.projects, 0)}</strong><span>projects to explore</span></div></div><Link className="btn btn-outline btn-sm btn-full" href="/admin/candidates">Explore the talent pool <ArrowRight size={13} /></Link></section>
      </div>
      <div className="admin-dashboard-grid admin-bottom-grid">
        <section className="panel"><div className="panel-heading"><div><h2>Active opportunities</h2><p>Roles where students can make an impact</p></div><Link className="text-link" href="/admin/internships">Manage all <ArrowRight /></Link></div><div className="admin-role-list">{state.internships.slice(0, 4).map((internship) => <div className="admin-role-row" key={internship.id}><CompanyLogo internship={internship} small /><div><strong>{internship.title}</strong><span>{internship.company} · {internship.mode}</span></div><span className="applicant-count"><Users size={12} />{internship.applicants}</span><span className="status-pill Offer">Open</span></div>)}</div></section>
        <section className="panel"><div className="panel-heading"><div><h2>Shortlist workspace</h2><p>Your saved candidates, ready for review</p></div><Link className="text-link" href="/admin/shortlist">Open shortlist <ArrowRight /></Link></div>{shortlist.length ? <div className="shortlist-preview">{shortlist.slice(0, 3).map((candidate) => <div className="shortlist-preview-row" key={candidate.id}><span className="avatar sm">{candidate.initials}</span><div><strong>{candidate.name}</strong><span>{candidate.major}</span></div><span className="match-badge"><Sparkles size={10} />{role ? recruiterMatch(candidate, role) : candidate.match}%</span></div>)}</div> : <EmptyState title="Your shortlist is ready" description="Save a candidate to make a collaborative review list." action={<Link className="btn btn-outline btn-sm" href="/admin/candidates">Find candidates</Link>} icon={<Heart size={20} />} />}</section>
      </div>
    </AppShell>
  );
}

export function CandidateManagementPage() {
  const { state, toggleCandidateShortlist } = useDemo();
  const [query, setQuery] = useState("");
  const [roleId, setRoleId] = useState("");
  const [minMatch, setMinMatch] = useState("Any fit");
  const [sort, setSort] = useState("Best fit");
  const [candidateId, setCandidateId] = useState<string | null>(null);
  const currentRole = state.internships.find((internship) => internship.id === roleId) ?? state.internships[0];
  const selectedCandidate = candidates.find((candidate) => candidate.id === candidateId);
  const filtered = useMemo(() => {
    let filteredCandidates = candidates.filter((candidate) => {
      const score = currentRole ? recruiterMatch(candidate, currentRole) : candidate.match;
      const terms = `${candidate.name} ${candidate.major} ${candidate.school} ${candidate.location} ${candidate.skills.join(" ")}`.toLowerCase();
      return (!query.trim() || terms.includes(query.trim().toLowerCase())) && (minMatch === "Any fit" || score >= Number(minMatch));
    });
    filteredCandidates = [...filteredCandidates].sort((left, right) => sort === "Name" ? left.name.localeCompare(right.name) : (currentRole ? recruiterMatch(right, currentRole) - recruiterMatch(left, currentRole) : right.match - left.match));
    return filteredCandidates;
  }, [query, currentRole, minMatch, sort]);

  return (
    <AppShell admin>
      <PageHeader title="Candidate management" description="Discover students through skills, shipped work and demonstrated initiative." action={<Link className="btn btn-outline btn-sm" href="/admin/shortlist"><Heart size={14} /> My shortlist <span className="button-count">{state.shortlistedCandidates.length}</span></Link>} />
      <div className="candidate-callout"><span><Sparkles size={17} /></span><div><strong>Look beyond a keyword match.</strong><p>Student profiles highlight projects, interests and hackathon results alongside the skills that matter to your role.</p></div><Link className="text-link" href="/admin/shortlist">About your shortlist <ArrowRight /></Link></div>
      <section className="panel candidate-browser"><div className="candidate-filter-bar"><div className="search-input-wrap"><Search /><input className="search-input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search name, school, skill or location" aria-label="Search candidates" /></div><select className="select-control" value={roleId} onChange={(event) => setRoleId(event.target.value)} aria-label="Match candidates to a role"><option value="">Best overall fit</option>{state.internships.map((internship) => <option value={internship.id} key={internship.id}>{internship.title}</option>)}</select><select className="select-control" value={minMatch} onChange={(event) => setMinMatch(event.target.value)} aria-label="Minimum match score"><option>Any fit</option><option value="90">90%+ fit</option><option value="80">80%+ fit</option><option value="70">70%+ fit</option></select><select className="select-control" value={sort} onChange={(event) => setSort(event.target.value)} aria-label="Sort candidates"><option>Best fit</option><option>Name</option></select></div><div className="candidate-results-meta"><span><strong>{filtered.length}</strong> of {candidates.length} candidate profiles</span><span>{currentRole ? `Matched to ${currentRole.title}` : "Ranked by overall candidate signals"}</span></div>
        <div className="table-wrap"><table className="data-table candidate-table"><thead><tr><th>Student</th><th>Role fit</th><th>Strengths</th><th>Portfolio</th><th>Interests</th><th>Actions</th></tr></thead><tbody>{filtered.map((candidate, index) => { const score = currentRole ? recruiterMatch(candidate, currentRole) : candidate.match; const shortlisted = state.shortlistedCandidates.includes(candidate.id); return <tr key={candidate.id}><td><div className="table-person"><span className={`avatar sm ${["", "blue", "green", "orange", "pink"][index % 5]}`}>{candidate.initials}</span><div><strong>{candidate.name}</strong><span>{candidate.major} · {candidate.year} · {candidate.school}</span></div></div></td><td><div className="match-meter"><div className="match-meter-track"><span style={{ width: `${score}%` }} /></div><b>{score}%</b></div></td><td><div className="table-skill-tags">{candidate.skills.slice(0, 3).map((skill) => <span className="skill-pill" key={skill}>{skill}</span>)}</div></td><td><span className="portfolio-signal"><FolderIcon />{candidate.projects} projects · {candidate.hackathons} hackathons · {candidate.certifications.length} credentials</span></td><td>{candidate.interest}</td><td><div className="table-actions"><button className="btn btn-ghost btn-sm" type="button" onClick={() => setCandidateId(candidate.id)}>View profile</button><button className={`btn-icon shortlist-icon${shortlisted ? " active" : ""}`} type="button" onClick={() => toggleCandidateShortlist(candidate.id)} aria-label={shortlisted ? `Remove ${candidate.name} from shortlist` : `Add ${candidate.name} to shortlist`} title={shortlisted ? "Remove from shortlist" : "Add to shortlist"}><Heart size={14} fill={shortlisted ? "currentColor" : "none"} /></button></div></td></tr>; })}</tbody></table></div>
        {!filtered.length && <EmptyState title="No candidates match those filters" description="Try broadening your search or lowering the minimum match score." icon={<Search size={23} />} action={<button className="btn btn-outline btn-sm" type="button" onClick={() => { setQuery(""); setMinMatch("Any fit"); }}>Clear filters</button>} />}
      </section>
      {selectedCandidate && <Modal title={selectedCandidate.name} description={`${selectedCandidate.major} · ${selectedCandidate.school} · ${selectedCandidate.year}`} onClose={() => setCandidateId(null)}><div className="candidate-profile-modal"><div className="candidate-modal-hero"><span className="profile-avatar-large">{selectedCandidate.initials}</span><div><span className="section-label">STUDENT PROFILE</span><h3>{selectedCandidate.major}</h3><p><MapPin size={12} />{selectedCandidate.location}</p></div><span className="match-badge"><Sparkles />{currentRole ? recruiterMatch(selectedCandidate, currentRole) : selectedCandidate.match}% fit</span></div><div className="candidate-modal-facts"><div><strong>{selectedCandidate.projects}</strong><span>Portfolio projects</span></div><div><strong>{selectedCandidate.hackathons}</strong><span>Hackathons</span></div><div><strong>{selectedCandidate.year}</strong><span>Student year</span></div></div><h4>Skills & experience</h4><div className="card-skills">{selectedCandidate.skills.map((skill) => <span className="skill-pill match" key={skill}>{skill}</span>)}</div><h4 className="candidate-cert-heading">Certifications & credentials</h4><div className="card-skills">{selectedCandidate.certifications.length ? selectedCandidate.certifications.map((certification) => <span className="skill-pill success" key={certification}>{certification}</span>) : <span className="finding-empty">No certifications listed yet.</span>}</div><div className="candidate-interest-note"><Target size={14} /><span>Interested in <strong>{selectedCandidate.interest}</strong></span></div><div className="modal-actions"><button className="btn btn-ghost" type="button" onClick={() => setCandidateId(null)}>Close</button><button className={`btn ${state.shortlistedCandidates.includes(selectedCandidate.id) ? "btn-outline" : "btn-primary"}`} type="button" onClick={() => toggleCandidateShortlist(selectedCandidate.id)}><Heart size={14} fill={state.shortlistedCandidates.includes(selectedCandidate.id) ? "currentColor" : "none"} />{state.shortlistedCandidates.includes(selectedCandidate.id) ? "Remove from shortlist" : "Add to shortlist"}</button></div></div></Modal>}
    </AppShell>
  );
}

function FolderIcon() {
  return <span className="inline-folder-icon" aria-hidden="true"><BriefcaseBusiness size={12} /></span>;
}

type InternshipForm = Omit<Internship, "id">;
const blankInternship: InternshipForm = {
  title: "",
  company: "",
  logo: "N",
  logoColor: "lavender",
  location: "Remote · US",
  mode: "Remote",
  type: "Internship",
  salary: "$25–30 / hr",
  posted: "Today",
  duration: "12 weeks",
  category: "Software development",
  description: "",
  skills: [],
  applicants: 0,
  featured: false,
};

export function InternshipManagementPage() {
  const { state, addInternship, updateInternship, removeInternship } = useDemo();
  const [query, setQuery] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<InternshipForm>(blankInternship);
  const [skillText, setSkillText] = useState("");
  const [notice, setNotice] = useState("");
  const filtered = state.internships.filter((internship) => `${internship.title} ${internship.company} ${internship.category}`.toLowerCase().includes(query.toLowerCase()));

  function openNew() { setEditingId(null); setDraft({ ...blankInternship }); setSkillText(""); setModalOpen(true); }
  function openEdit(internship: Internship) { const { id, ...details } = internship; setEditingId(id); setDraft({ ...details, skills: [...details.skills] }); setSkillText(details.skills.join(", ")); setModalOpen(true); }

  function submitInternship(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const skillList = skillText.split(",").map((skill) => skill.trim()).filter(Boolean);
    const value = { ...draft, logo: titleLogo(draft.company), skills: skillList };
    if (!value.title.trim() || !value.company.trim() || !skillList.length) return;
    if (editingId) { updateInternship(editingId, value); setNotice("Internship details updated. Student match scores refreshed."); }
    else { addInternship(value); setNotice("Your new internship is published in the student opportunity explorer."); }
    setModalOpen(false);
  }

  function deleteRole(id: string, title: string) {
    if (window.confirm(`Remove “${title}” from your demo opportunities?`)) { removeInternship(id); setNotice("Internship removed from the workspace."); }
  }

  return (
    <AppShell admin>
      <PageHeader title="Internship management" description="Create, update and manage the opportunities students can discover." action={<button className="btn btn-primary btn-sm" type="button" onClick={openNew}><Plus size={14} /> Add an internship</button>} />
      <section className="stats-grid internship-admin-stats"><StatCard title="Published roles" value={state.internships.length} hint="Visible in student explore" icon={<BriefcaseBusiness />} /><StatCard title="Featured roles" value={state.internships.filter((item) => item.featured).length} hint="Highlighted on the landing page" tone="blue" icon={<Sparkles />} /><StatCard title="Student interest" value={state.internships.reduce((total, item) => total + item.applicants, 0)} hint="Sample applicants across roles" tone="green" icon={<Users />} /><StatCard title="Role categories" value={new Set(state.internships.map((item) => item.category)).size} hint="Across different paths" tone="orange" icon={<Target />} /></section>
      {notice && <Feedback>{notice}</Feedback>}
      <section className="panel admin-internship-panel"><div className="admin-list-toolbar"><div className="search-input-wrap"><Search /><input className="search-input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search job title, company or category" aria-label="Search internships" /></div><span className="admin-results-count">{filtered.length} roles</span></div><div className="table-wrap"><table className="data-table"><thead><tr><th>Opportunity</th><th>Work mode</th><th>Core skills</th><th>Interest</th><th>Recruitment</th><th>Manage</th></tr></thead><tbody>{filtered.map((internship) => <tr key={internship.id}><td><div className="table-person"><CompanyLogo internship={internship} small /><div><strong>{internship.title}</strong><span>{internship.company} · {internship.location}</span></div></div></td><td><span className="mode-label">{internship.mode}</span></td><td><div className="table-skill-tags">{internship.skills.slice(0, 3).map((skill) => <span className="skill-pill" key={skill}>{skill}</span>)}{internship.skills.length > 3 && <span className="skill-pill">+{internship.skills.length - 3}</span>}</div></td><td><span className={`status-pill ${internship.featured ? "Offer" : "In-review"}`}>{internship.featured ? "Featured" : "Open"}</span></td><td><span className="applicant-count"><Users size={12} />{internship.applicants} applicants</span></td><td><div className="table-actions"><button className="btn btn-ghost btn-sm" type="button" onClick={() => openEdit(internship)}>Edit</button><Link className="btn-icon" href={`/internships/${internship.id}`} aria-label={`Preview ${internship.title}`}><ExternalLink size={13} /></Link><button className="btn-icon mini-danger" type="button" onClick={() => deleteRole(internship.id, internship.title)} aria-label={`Remove ${internship.title}`}><Trash2 size={13} /></button></div></td></tr>)}</tbody></table></div>{!filtered.length && <EmptyState title="No internships found" description="Try another search or create a new role." icon={<Search size={22} />} action={<button className="btn btn-primary btn-sm" type="button" onClick={openNew}>Add an internship</button>} />}</section>
      <div className="admin-help-note"><Sparkles size={14} /><span>Changes are saved in this browser and instantly update student opportunity cards, details and match scores.</span></div>
      {modalOpen && <Modal title={editingId ? "Edit internship" : "Create an internship"} description="Give students the details they need to see if this opportunity fits." onClose={() => setModalOpen(false)}><form className="internship-form" onSubmit={submitInternship}><div className="field-row"><div className="form-field"><label className="field-label" htmlFor="role-title">Role title</label><input id="role-title" className="field-input" value={draft.title} onChange={(event) => setDraft({ ...draft, title: event.target.value })} required autoFocus /></div><div className="form-field"><label className="field-label" htmlFor="role-company">Company</label><input id="role-company" className="field-input" value={draft.company} onChange={(event) => setDraft({ ...draft, company: event.target.value })} required /></div></div><div className="field-row"><div className="form-field"><label className="field-label" htmlFor="role-location">Location</label><input id="role-location" className="field-input" value={draft.location} onChange={(event) => setDraft({ ...draft, location: event.target.value })} required /></div><div className="form-field"><label className="field-label" htmlFor="role-mode">Work mode</label><select id="role-mode" className="field-select" value={draft.mode} onChange={(event) => setDraft({ ...draft, mode: event.target.value as Internship["mode"] })}><option>Remote</option><option>Hybrid</option><option>On-site</option></select></div></div><div className="field-row"><div className="form-field"><label className="field-label" htmlFor="role-salary">Compensation</label><input id="role-salary" className="field-input" value={draft.salary} onChange={(event) => setDraft({ ...draft, salary: event.target.value })} /></div><div className="form-field"><label className="field-label" htmlFor="role-duration">Duration</label><input id="role-duration" className="field-input" value={draft.duration} onChange={(event) => setDraft({ ...draft, duration: event.target.value })} /></div></div><div className="field-row"><div className="form-field"><label className="field-label" htmlFor="role-category">Role category</label><select id="role-category" className="field-select" value={draft.category} onChange={(event) => setDraft({ ...draft, category: event.target.value })}>{["Software development", "Data & analytics", "Design & product", "AI & machine learning", "Marketing & creative", "Cybersecurity", "Other"].map((category) => <option key={category}>{category}</option>)}</select></div><div className="form-field"><label className="field-label" htmlFor="role-applicants">Current interest (demo)</label><input id="role-applicants" className="field-input" type="number" min="0" value={draft.applicants} onChange={(event) => setDraft({ ...draft, applicants: Number(event.target.value) })} /></div></div><div className="form-field"><label className="field-label" htmlFor="role-skills">Required skills (comma separated)</label><input id="role-skills" className="field-input" value={skillText} onChange={(event) => setSkillText(event.target.value)} placeholder="Python, SQL, communication" required /><div className="field-help">These skills power transparent student match scores.</div></div><div className="form-field"><label className="field-label" htmlFor="role-description">About this opportunity</label><textarea id="role-description" className="field-textarea" value={draft.description} onChange={(event) => setDraft({ ...draft, description: event.target.value })} required /></div><label className="checkbox-line"><input type="checkbox" checked={Boolean(draft.featured)} onChange={(event) => setDraft({ ...draft, featured: event.target.checked })} /><span>Feature this opportunity on the landing page</span></label><div className="modal-actions"><button className="btn btn-ghost" type="button" onClick={() => setModalOpen(false)}>Cancel</button><button className="btn btn-primary" type="submit">{editingId ? "Save changes" : "Publish internship"}<Check size={13} /></button></div></form></Modal>}
    </AppShell>
  );
}

export function ShortlistManagementPage() {
  const { state, toggleCandidateShortlist } = useDemo();
  const [roleId, setRoleId] = useState("");
  const [query, setQuery] = useState("");
  const [notice, setNotice] = useState("");
  const role = state.internships.find((internship) => internship.id === roleId) ?? state.internships[0];
  const selected = candidates.filter((candidate) => state.shortlistedCandidates.includes(candidate.id)).filter((candidate) => !query || `${candidate.name} ${candidate.skills.join(" ")} ${candidate.major}`.toLowerCase().includes(query.toLowerCase())).sort((left, right) => (role ? recruiterMatch(right, role) - recruiterMatch(left, role) : right.match - left.match));

  function exportCsv() {
    if (!selected.length) { setNotice("Add a candidate to your shortlist before exporting."); return; }
    const rows = [["Name", "Major", "University", "Year", "Match", "Skills", "Projects", "Hackathons"], ...selected.map((candidate) => [candidate.name, candidate.major, candidate.school, candidate.year, `${role ? recruiterMatch(candidate, role) : candidate.match}%`, candidate.skills.join("; "), String(candidate.projects), String(candidate.hackathons)])];
    const csv = rows.map((row) => row.map((cell) => `"${cell.replaceAll('"', '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url; link.download = "internmatch-shortlist.csv"; document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
    setNotice("Shortlist exported as a CSV file.");
  }

  return (
    <AppShell admin>
      <PageHeader title="Shortlist management" description="Keep the candidates you want to learn more about in one thoughtful review list." action={<div className="portfolio-actions"><Link className="btn btn-outline btn-sm" href="/admin/candidates"><Users size={13} /> Find candidates</Link><button className="btn btn-primary btn-sm" type="button" onClick={exportCsv}><Download size={13} /> Export shortlist</button></div>} />
      <div className="shortlist-intro"><div className="shortlist-heart"><Heart size={19} fill="currentColor" /></div><div><span>YOUR REVIEW SPACE</span><h2>{state.shortlistedCandidates.length} candidate{state.shortlistedCandidates.length === 1 ? "" : "s"} saved for a closer look</h2><p>Shortlist candidates from the talent pool, compare role fit and export a shareable snapshot.</p></div><span className="shortlist-illustration"><Users size={43} /><Sparkles size={17} /></span></div>
      <section className="panel shortlist-panel"><div className="shortlist-controls"><div className="search-input-wrap"><Search /><input className="search-input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Filter your shortlist" aria-label="Search shortlist" /></div><select className="select-control" value={roleId} onChange={(event) => setRoleId(event.target.value)} aria-label="Choose role for candidate fit"><option value="">Best overall fit</option>{state.internships.map((internship) => <option key={internship.id} value={internship.id}>{internship.title}</option>)}</select><span className="shortlist-sort"><ArrowDownUp size={13} /> Sorted by fit</span></div>
        {notice && <Feedback>{notice}</Feedback>}
        {selected.length ? <div className="shortlist-grid">{selected.map((candidate, index) => { const score = role ? recruiterMatch(candidate, role) : candidate.match; return <article className="shortlist-card" key={candidate.id}><div className="shortlist-card-top"><span className={`avatar shortlist-avatar ${["", "blue", "green", "orange", "pink"][index % 5]}`}>{candidate.initials}</span><button className="btn-icon active mini-danger" type="button" onClick={() => toggleCandidateShortlist(candidate.id)} aria-label={`Remove ${candidate.name} from shortlist`} title="Remove from shortlist"><Heart size={14} fill="currentColor" /></button></div><div className="shortlist-candidate-id"><h3>{candidate.name}</h3><p>{candidate.major} · {candidate.year}</p><span>{candidate.school} · {candidate.location}</span></div><div className="shortlist-fit-row"><span className="match-badge"><Sparkles size={11} />{score}% {role ? "role fit" : "overall fit"}</span><span className="shortlist-interest">{candidate.interest}</span></div><div className="card-skills">{candidate.skills.slice(0, 4).map((skill) => <span className="skill-pill" key={skill}>{skill}</span>)}</div><div className="shortlist-card-bottom"><span><BriefcaseBusiness size={12} />{candidate.projects} projects</span><span><Award size={12} />{candidate.hackathons} hackathons</span></div><Link className="btn btn-outline btn-sm btn-full" href="/admin/candidates">Review candidate <ArrowRight size={12} /></Link></article>; })}</div> : <EmptyState title={state.shortlistedCandidates.length ? "No shortlist results" : "Your shortlist is ready to take shape"} description={state.shortlistedCandidates.length ? "Try a different search or add more candidates from the talent pool." : "Explore candidates and tap the heart on the profiles you want to revisit."} action={<Link className="btn btn-primary btn-sm" href="/admin/candidates">Explore candidates <Users size={13} /></Link>} icon={<Heart size={23} />} />}
      </section>
      <div className="shortlist-privacy-note"><CheckCircle2 size={14} /><span>Your shortlist is stored locally in this demo browser. No student data is sent to a server.</span><Link className="text-link" href="/admin/candidates">Add a candidate <ArrowRight /></Link></div>
    </AppShell>
  );
}
