"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent, type KeyboardEvent } from "react";
import Link from "next/link";
import {
  ArrowRight,
  Bot,
  Brain,
  Check,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Download,
  FileText,
  Lightbulb,
  Loader2,
  Mail,
  MapPin,
  Mic,
  Paperclip,
  Send,
  ShieldCheck,
  Sparkles,
  Star,
  Target,
  Trash2,
  Upload,
  User,
  X,
} from "lucide-react";
import { useDemo } from "@/lib/demo-store";
import { AppShell, EmptyState, Feedback, Modal, PageHeader, StatCard } from "@/components/common";

// Sample interview questions bank categorized by skill/area
const interviewQuestionsBank: Record<string, string[]> = {
  python: [
    "Can you explain the difference between a list and a tuple in Python?",
    "How do you handle exceptions in Python? Can you show an example?",
    "What are Python decorators and when would you use them?",
    "How would you optimize a slow Python function?",
    "Can you explain list comprehensions vs generator expressions?",
  ],
  react: [
    "What is the difference between state and props in React?",
    "How do React hooks work? Explain useState and useEffect.",
    "What are controlled vs uncontrolled components?",
    "How would you optimize a React application's performance?",
    "What is the virtual DOM and how does React use it?",
  ],
  sql: [
    "What's the difference between INNER JOIN and LEFT JOIN?",
    "How do you optimize a slow SQL query?",
    "What are indexes and how do they improve query performance?",
    "Can you explain database normalization?",
    "What's the difference between WHERE and HAVING clauses?",
  ],
  javascript: [
    "What is the difference between let, const, and var?",
    "How does this keyword work in JavaScript?",
    "Can you explain closures in JavaScript?",
    "What are promises and how do they differ from callbacks?",
    "What is the event loop in JavaScript?",
  ],
  general: [
    "Tell me about yourself and your background.",
    "What projects are you most proud of and why?",
    "How do you approach learning a new technology or framework?",
    "Describe a challenging problem you solved and how you approached it.",
    "What are your career goals and how does this internship fit into them?",
    "How do you work in a team environment?",
    "What is your greatest strength as a developer?",
    "Describe a time you faced a technical challenge and how you overcame it.",
  ],
  behavior: [
    "How do you handle tight deadlines?",
    "Describe a time you had to work with a difficult team member.",
    "How do you prioritize tasks when everything is urgent?",
    "Tell me about a mistake you made and what you learned from it.",
    "How do you stay motivated when working on long-term projects?",
  ],
  "machine learning": [
    "What machine learning frameworks have you used?",
    "Can you explain the difference between supervised and unsupervised learning?",
    "How would you evaluate the performance of a machine learning model?",
    "What is overfitting and how do you prevent it?",
    "Can you explain how a neural network works at a high level?",
  ],
  "data analysis": [
    "What tools do you use for data visualization?",
    "How do you clean and preprocess data before analysis?",
    "Can you explain the difference between correlation and causation?",
    "What statistical methods are you familiar with?",
    "How would you communicate complex data insights to a non-technical audience?",
  ],
};

// Keywords that indicate real resume content
const realResumeKeywords = [
  "education", "experience", "skills", "projects", "internship", "worked", "built",
  "developed", "implemented", "designed", "collaborated", "achieved", "graduated",
  "bachelor", "master", "university", "college", "school", "github", "linkedin",
  "contact", "email", "phone", "address", "objective", "summary",
];

// Keywords that might indicate a fake/generic resume
const fakeResumeKeywords = [
  "lorem ipsum", "dummy", "sample", "template", "placeholder", "test",
  "example", "generic", "filler", "random", "fake", "demo content",
];

// Extract skills from text
function extractSkills(text: string): { skills: string[]; confidence: number } {
  const skillPatterns = [
    "python", "java", "c++", "c#", "javascript", "typescript", "react", "angular",
    "vue", "node", "express", "django", "flask", "fastapi", "spring",
    "sql", "mysql", "postgresql", "mongodb", "git", "github", "docker",
    "aws", "azure", "gcp", "html", "css", "sass", "tailwind",
    "machine learning", "ai", "nlp", "computer vision", "pytorch", "tensorflow",
    "pandas", "numpy", "matplotlib", "seaborn", "tableau", "power bi",
    "figma", "photoshop", "illustrator", "adobe xd", "sketch",
    "agile", "scrum", "kanban", "jira", "trello", "confluence",
  ];

  const foundSkills: string[] = [];
  const lowerText = text.toLowerCase();
  
  skillPatterns.forEach((skill) => {
    if (lowerText.includes(skill) && !foundSkills.includes(skill)) {
      foundSkills.push(skill);
    }
  });

  // Confidence based on number of skills found and detail level
  const detailLevel = Math.min(text.length / 500, 1);
  const confidence = Math.min(95, foundSkills.length * 5 + detailLevel * 20);

  return { skills: foundSkills.sort(), confidence };
}

// Extract education from text
function extractEducation(text: string): { schools: string[]; degrees: string[]; confidence: number } {
  const schoolPatterns = ["university", "college", "institute", "school", "academy"];
  const degreePatterns = ["bachelor", "master", "phd", "mba", "bs", "ba", "ms", "mca", "btech", "mtech"];

  const schools: string[] = [];
  const degrees: string[] = [];
  const lowerText = text.toLowerCase();

  schoolPatterns.forEach((pattern) => {
    const regex = new RegExp(`(?<= |^)${pattern}[ a-z]*[,.]?`, "gi");
    const matches = text.match(regex) || [];
    matches.forEach((match) => {
      if (!schools.includes(match.trim()) && match.trim().length > 5) {
        schools.push(match.trim());
      }
    });
  });

  degreePatterns.forEach((pattern) => {
    const regex = new RegExp(`(?<= |^)${pattern}(?= |,|\.|$)`, "gi");
    const matches = text.match(regex) || [];
    matches.forEach((match) => {
      if (!degrees.includes(match.trim())) {
        degrees.push(match.trim());
      }
    });
  });

  const confidence = schools.length > 0 || degrees.length > 0 ? 85 : 30;
  return { schools, degrees, confidence };
}

// Extract experience from text
function extractExperience(text: string): { companies: string[]; positions: string[]; years: number; confidence: number } {
  const companies: string[] = [];
  const positions: string[] = [];
  let years = 0;

  // Simple pattern matching for companies (capitalized words/phrases)
  const companyKeywords = ["google", "microsoft", "amazon", "facebook", "apple", "netflix", "uber", "lyft", "airbnb",
    "tesla", "spacex", "nvidia", "intel", "ibm", "oracle", "salesforce", "adobe",
    "startup", "company", "corporation", "inc", "llc", "ltd"];

  const lowerText = text.toLowerCase();
  
  companyKeywords.forEach((keyword) => {
    if (lowerText.includes(keyword)) {
      const regex = new RegExp(`[A-Z][a-z]+(?= |,|\.|$)|${keyword}`, "gi");
      const matches = text.match(regex) || [];
      matches.forEach((match) => {
        const clean = match.replace(/[^a-zA-Z0-9 ]/g, "").trim();
        if (clean && !companies.includes(clean) && clean.length > 2) {
          companies.push(clean);
        }
      });
    }
  });

  // Extract positions
  const positionKeywords = ["developer", "engineer", "intern", "analyst", "designer", "manager",
    "lead", "senior", "junior", "associate", "specialist", "coordinator"];

  positionKeywords.forEach((keyword) => {
    const regex = new RegExp(`(?<= |^)${keyword}[ a-z]*`, "gi");
    const matches = text.match(regex) || [];
    matches.forEach((match) => {
      if (!positions.includes(match.trim())) {
        positions.push(match.trim());
      }
    });
  });

  // Extract years of experience
  const yearMatches = text.match(/\b\d+[.\d]*\s*(?:years?|yrs?|y)\b/gi) || [];
  yearMatches.forEach((match) => {
    const num = parseFloat(match);
    if (!isNaN(num)) {
      years = Math.max(years, num);
    }
  });

  const confidence = companies.length > 0 || positions.length > 0 ? 80 : 40;
  return { companies, positions, years, confidence };
}

// Analyze resume for authenticity
function analyzeResumeAuthenticity(text: string): {
  isReal: boolean;
  confidence: number;
  reasons: string[];
  score: number;
} {
  const reasons: string[] = [];
  const lowerText = text.toLowerCase();
  let score = 50; // Start neutral

  // Check for fake indicators
  fakeResumeKeywords.forEach((keyword) => {
    if (lowerText.includes(keyword)) {
      reasons.push(`Contains placeholder text: "${keyword}"`);
      score -= 20;
    }
  });

  // Check for real indicators
  realResumeKeywords.forEach((keyword) => {
    if (lowerText.includes(keyword)) {
      score += 3;
    }
  });

  // Check text length
  if (text.length < 200) {
    reasons.push("Resume is too short to be authentic");
    score -= 15;
  } else if (text.length > 5000) {
    reasons.push("Resume is unusually long");
    score -= 10;
  } else {
    score += 5;
  }

  // Check for personal information patterns
  const hasEmail = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i.test(text);
  const hasPhone = /\+?\d[\d -]{7,}\d/i.test(text);
  const hasName = /[A-Z][a-z]+ [A-Z][a-z]+/.test(text);

  if (hasEmail) {
    reasons.push("Contains email address");
    score += 5;
  }
  if (hasPhone) {
    reasons.push("Contains phone number");
    score += 5;
  }
  if (hasName) {
    reasons.push("Contains proper name");
    score += 5;
  }

  // Check for consistent formatting
  const hasBulletPoints = text.includes("•") || text.includes("-") || text.includes("*");
  const hasSections = /(education|experience|skills|projects|contact)/i.test(text);
  const hasDates = /\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]* \d{4}\b/.test(text) || /\b\d{4} - \d{4}\b/.test(text);

  if (hasBulletPoints) {
    reasons.push("Uses bullet points for clarity");
    score += 3;
  }
  if (hasSections) {
    reasons.push("Has standard resume sections");
    score += 5;
  }
  if (hasDates) {
    reasons.push("Includes dates/tenure");
    score += 5;
  }

  // Clamp score and determine result
  score = Math.min(100, Math.max(0, score));
  const isReal = score >= 70;
  const confidence = score;

  if (!reasons.length) {
    reasons.push("Resume appears to be a standard document");
  }

  return { isReal, confidence, reasons, score };
}

// Generate interview questions based on resume content
function generateInterviewQuestions(resumeText: string, count = 5): { questions: string[]; topics: string[] } {
  const lowerText = resumeText.toLowerCase();
  const topics: string[] = [];
  const questions: string[] = [];

  // Detect topics from resume
  const topicMap: Record<string, string> = {
    python: "Python",
    java: "Java",
    javascript: "JavaScript",
    react: "React",
    sql: "SQL",
    "machine learning": "Machine Learning",
    "data analysis": "Data Analysis",
    html: "HTML/CSS",
    css: "HTML/CSS",
  };

  Object.entries(topicMap).forEach(([key, label]) => {
    if (lowerText.includes(key) && !topics.includes(label)) {
      topics.push(label);
    }
  });

  // If no specific topics found, use general
  if (topics.length === 0) {
    topics.push("General");
  }

  // Select questions from bank based on topics
  topics.forEach((topic) => {
    const key = topic.toLowerCase();
    const topicQuestions = interviewQuestionsBank[key] || interviewQuestionsBank.general;
    // Pick 1-2 random questions from this topic
    const shuffled = [...topicQuestions].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, Math.min(2, shuffled.length));
    selected.forEach((q) => {
      if (!questions.includes(q)) {
        questions.push(q);
      }
    });
  });

  // Fill up to count with general questions if needed
  const generalQuestions = interviewQuestionsBank.general.filter(
    (q) => !questions.includes(q)
  );
  while (questions.length < count && generalQuestions.length > 0) {
    const randomQ = generalQuestions[Math.floor(Math.random() * generalQuestions.length)];
    if (!questions.includes(randomQ)) {
      questions.push(randomQ);
    }
  }

  // Always include at least one behavioral question
  if (!questions.some((q) => interviewQuestionsBank.behavior.includes(q))) {
    const behaviorQ = interviewQuestionsBank.behavior[Math.floor(Math.random() * interviewQuestionsBank.behavior.length)];
    if (!questions.includes(behaviorQ)) {
      questions.push(behaviorQ);
    }
  }

  return { questions, topics };
}

// Mock AI responses
function generateAIResponse(
  userMessage: string,
  resumeText: string,
  chatHistory: Array<{ role: "user" | "assistant"; content: string }>
): { response: string; followUp: string | null; score: number | null } {
  const lowerMessage = userMessage.toLowerCase();
  const lowerResume = resumeText.toLowerCase();

  // If user uploaded resume
  if (lowerMessage.includes("analyze") || lowerMessage.includes("review") || lowerMessage.includes("check")) {
    const { isReal, confidence, reasons, score } = analyzeResumeAuthenticity(resumeText);
    const { skills } = extractSkills(resumeText);
    const { schools, degrees } = extractEducation(resumeText);
    const { companies, positions, years } = extractExperience(resumeText);

    let response = `I've analyzed your resume!\n\n**Authenticity Assessment: ${confidence}%**\n\n`;
    
    if (isReal) {
      response += "✅ **This appears to be a REAL resume.**\n\n";
    } else {
      response += "⚠️ **This may need verification.**\n\n";
    }

    response += `**Reasons:**\n`;
    reasons.forEach((reason) => {
      response += `• ${reason}\n`;
    });

    response += `\n**Extracted Information:**\n\n`;
    
    if (skills.length > 0) {
      response += `**Skills:** ${skills.join(", ")}\n\n`;
    }
    if (schools.length > 0 || degrees.length > 0) {
      response += `**Education:** ${degrees.length > 0 ? degrees.join(", ") + " - " : ""}${schools.join(", ")}\n\n`;
    }
    if (companies.length > 0 || positions.length > 0 || years > 0) {
      response += `**Experience:** ${positions.join(", ")} ${companies.length > 0 ? "at " + companies.join(", ") : ""}${years > 0 ? ` (${years}+ years)` : ""}\n\n`;
    }

    if (skills.length > 0) {
      response += "Would you like me to conduct a mock interview based on your skills? 🎯";
      return { response, followUp: "mock interview", score: confidence };
    }

    return { response, followUp: null, score: confidence };
  }

  // If user wants mock interview
  if (lowerMessage.includes("interview") || lowerMessage.includes("mock") || lowerMessage.includes("practice")) {
    const { questions, topics } = generateInterviewQuestions(resumeText, 5);
    
    let response = `🎯 **Mock Interview Mode Activated!**\n\n`;
    response += `Based on your resume, I'll focus on: **${topics.join(", ")}**\n\n`;
    response += `**Your first question:**\n\n`;
    response += `**Q1:** ${questions[0]}\n\n`;
    response += `Take your time to answer. I'll provide feedback and we'll continue through ${questions.length} questions.`;

    return { response, followUp: "interview", score: null };
  }

  // If user answered an interview question
  const lastAssistantMsg = chatHistory.findLast((msg) => msg.role === "assistant")?.content || "";
  if (lastAssistantMsg.includes("Q") && lastAssistantMsg.includes(":")) {
    // Extract question number
    const qMatch = lastAssistantMsg.match(/Q(\d+)/);
    const qNum = qMatch ? parseInt(qMatch[1]) : 1;
    const nextQNum = qNum + 1;
    
    const { questions } = generateInterviewQuestions(resumeText, 5);
    
    // Generate feedback for user's answer
    const answerLength = userMessage.trim().length;
    let feedback = "";
    let score = 0;

    if (answerLength < 20) {
      feedback = "⚠️ Your answer is quite short. Try to provide more detail and examples.";
      score = 3;
    } else if (answerLength < 50) {
      feedback = "✅ Good start! Consider adding specific examples or outcomes.";
      score = 6;
    } else if (answerLength < 100) {
      feedback = "✅ Excellent answer! You provided good detail.";
      score = 8;
    } else {
      feedback = "⭐ Exceptional answer! You demonstrated strong knowledge and experience.";
      score = 10;
    }

    let response = feedback;
    
    if (nextQNum <= questions.length) {
      response += `\n\n**Q${nextQNum}:** ${questions[nextQNum - 1]}`;
    } else {
      response += `\n\n🎉 **Mock Interview Complete!**\n\nYou did great! Based on your answers, here's your estimated interview score: **${Math.round((score * 100) / questions.length)}%**\n\n`;
      response += `**Recommendations:**\n`;
      response += `• Practice answering questions more concisely\n`;
      response += `• Use the STAR method (Situation, Task, Action, Result)\n`;
      response += `• Highlight specific achievements and metrics\n\n`;
      response += `Would you like to review your resume analysis or try another interview?`;
      return { response, followUp: "complete", score: score * 10 };
    }

    return { response, followUp: "interview", score };
  }

  // General chat responses
  const greetings = ["hi", "hello", "hey", "good morning", "good afternoon"];
  if (greetings.some((g) => lowerMessage.startsWith(g))) {
    return {
      response: `Hello! 👋 I'm your InternMatch AI assistant. I can help you:\n\n• **Analyze your resume** - Upload and I'll check authenticity and extract key info\n• **Conduct mock interviews** - Practice with AI-generated questions based on your resume\n• **Get interview feedback** - Receive scores and improvement tips\n\nWhat would you like to do?`,
      followUp: null,
      score: null,
    };
  }

  // Default response
  return {
    response: "I'm here to help with your internship preparation! You can upload your resume for analysis or request a mock interview. What would you like to do?",
    followUp: null,
    score: null,
  };
}

type Message = {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  id: string;
};

type ResumeAnalysis = {
  isReal: boolean;
  confidence: number;
  reasons: string[];
  score: number;
  skills: string[];
  education: string;
  experience: string;
  extractedText: string;
} | null;

export function ChatbotPage() {
  const { state } = useDemo();
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: `Hi there! 👋 I'm your InternMatch AI assistant.\n\nI can help you:\n• **Upload & analyze your resume** - Check authenticity and extract important details\n• **Conduct mock interviews** - Practice with AI-generated questions based on your resume\n• **Get personalized feedback** - Receive scores and improvement recommendations\n\nUpload your resume or type a message to get started!`,
      timestamp: new Date(),
      id: "welcome",
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [resumeText, setResumeText] = useState("");
  const [fileName, setFileName] = useState("");
  const [resumeAnalysis, setResumeAnalysis] = useState<ResumeAnalysis>(null);
  const [interviewActive, setInterviewActive] = useState(false);
  const [interviewScore, setInterviewScore] = useState<number | null>(null);
  const [showResumePreview, setShowResumePreview] = useState(false);
  const [showInterviewReport, setShowInterviewReport] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Generate initial interview questions when resume is uploaded
  const interviewQuestions = useMemo(() => {
    if (!resumeText) return [];
    const { questions } = generateInterviewQuestions(resumeText, 5);
    return questions;
  }, [resumeText]);

  // Handle file upload
  const handleFileUpload = useCallback(
    async (file: File) => {
      setIsLoading(true);
      setFileName(file.name);

      try {
        if (file.type === "text/plain" || file.name.toLowerCase().endsWith(".txt")) {
          const text = await file.text();
          setResumeText(text);
          analyzeResume(text);
        } else if (file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf")) {
          // For PDFs in this demo, we'll use a fallback text
          // In a real app, you'd use pdf-lib or similar
          const demoText = `InternMatch AI Demo Resume

SUMMARY
Passionate Computer Science student with experience in Python, React, and Machine Learning. Built multiple projects including a study buddy matching app and a campus climate dashboard.

EDUCATION
Bachelor of Science in Computer Science
University of California, Berkeley
Expected Graduation: 2027

SKILLS
• Python • FastAPI • SQL • Git • React • TypeScript • Machine Learning • Figma • Data Analysis

PROJECTS
StudyFlow - Smarter study groups
• Built a study buddy matching app for 400+ students
• Technologies: Python, FastAPI, React
• Deployed and maintained for 6 months

Campus Climate Dashboard
• Interactive dashboard for campus sustainability data
• Technologies: SQL, Data Analysis, Figma

ACHIEVEMENTS
• 1st Place - Social Impact Track, Cal Hacks 10.0
• AWS Cloud Practitioner Certification
• Google Data Analytics Certificate`;
          setResumeText(demoText);
          analyzeResume(demoText);
        } else {
          // Try to read as text
          const text = await file.text();
          setResumeText(text);
          analyzeResume(text);
        }
      } catch (error) {
        console.error("Error reading file:", error);
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content: "I couldn't read that file. Please upload a text file (.txt) or PDF (.pdf).",
            timestamp: new Date(),
            id: Date.now().toString(),
          },
        ]);
      } finally {
        setIsLoading(false);
      }
    },
    [setResumeText, setIsLoading, setFileName]
  );

  // Analyze uploaded resume
  const analyzeResume = useCallback(
    (text: string) => {
      const { isReal, confidence, reasons, score } = analyzeResumeAuthenticity(text);
      const { skills } = extractSkills(text);
      const { schools, degrees } = extractEducation(text);
      const { companies, positions, years } = extractExperience(text);

      const analysis: ResumeAnalysis = {
        isReal,
        confidence,
        reasons,
        score,
        skills,
        education: schools.length > 0 ? `${degrees.join(", ")} - ${schools.join(", ")}` : "Not specified",
        experience: positions.length > 0 ? `${positions.join(", ")} ${companies.length > 0 ? "at " + companies.join(", ") : ""}${years > 0 ? ` (${years}+ years)` : ""}` : "Not specified",
        extractedText: text,
      };

      setResumeAnalysis(analysis);

      // Add analysis message to chat
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: `✅ Resume uploaded: **${fileName || "resume.txt"}**\n\nI've extracted your resume content. Type "analyze" to get a detailed review, or "mock interview" to start practicing!`,
          timestamp: new Date(),
          id: Date.now().toString(),
        },
      ]);
    },
    [fileName]
  );

  // Handle sending message
  const handleSendMessage = useCallback(
    (e?: FormEvent | KeyboardEvent) => {
      if (e) {
        e.preventDefault();
      }

      if (!inputValue.trim() || isLoading) return;

      const userMessage: Message = {
        role: "user",
        content: inputValue.trim(),
        timestamp: new Date(),
        id: Date.now().toString(),
      };

      setInputValue("");
      setMessages((prev) => [...prev, userMessage]);
      setIsLoading(true);

      // Simulate AI thinking delay
      setTimeout(() => {
        const { response, followUp, score } = generateAIResponse(
          userMessage.content,
          resumeText || state.profile.bio,
          messages
        );

        const assistantMessage: Message = {
          role: "assistant",
          content: response,
          timestamp: new Date(),
          id: (Date.now() + 1).toString(),
        };

        setMessages((prev) => [...prev, assistantMessage]);

        if (followUp === "interview") {
          setInterviewActive(true);
        } else if (followUp === "complete") {
          setInterviewActive(false);
          setInterviewScore(score || null);
        } else if (followUp === "mock interview") {
          setShowInterviewReport(false);
        }

        setIsLoading(false);
      }, 800);
    },
    [inputValue, isLoading, resumeText, messages, state.profile.bio]
  );

  // Start new chat
  const handleNewChat = () => {
    setMessages([
      {
        role: "assistant",
        content: `Hi there! 👋 I'm your InternMatch AI assistant.\n\nI can help you:\n• **Upload & analyze your resume** - Check authenticity and extract important details\n• **Conduct mock interviews** - Practice with AI-generated questions based on your resume\n• **Get personalized feedback** - Receive scores and improvement recommendations\n\nUpload your resume or type a message to get started!`,
        timestamp: new Date(),
        id: "welcome",
      },
    ]);
    setResumeText("");
    setFileName("");
    setResumeAnalysis(null);
    setInterviewActive(false);
    setInterviewScore(null);
  };

  // Format time
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  // Download resume analysis as text
  const downloadAnalysis = () => {
    if (!resumeAnalysis) return;

    const content = `INTERNMATCH AI - RESUME ANALYSIS REPORT
Generated: ${new Date().toLocaleString()}

=== AUTHENTICITY ASSESSMENT ===
Confidence: ${resumeAnalysis.confidence}%
Status: ${resumeAnalysis.isReal ? "✅ REAL RESUME" : "⚠️ NEEDS VERIFICATION"}

Reasons:
${resumeAnalysis.reasons.map((r) => `• ${r}`).join("\n")}

=== EXTRACTED INFORMATION ===

Skills: ${resumeAnalysis.skills.join(", ")}
Education: ${resumeAnalysis.education}
Experience: ${resumeAnalysis.experience}

=== RESUME TEXT ===
${resumeAnalysis.extractedText}
`;

    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `resume-analysis-${Date.now()}.txt`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };

  // Handle file drag and drop
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) {
      void handleFileUpload(file);
    }
  };

  return (
    <AppShell>
      <PageHeader
        title="AI Chatbot & Resume Analyzer"
        description="Upload your resume for authenticity check and conduct mock interviews to improve your chances"
        action={
          <div className="chatbot-header-actions">
            <button className="btn btn-outline btn-sm" type="button" onClick={handleNewChat}>
              <X size={13} /> New Chat
            </button>
            {resumeAnalysis && (
              <button className="btn btn-primary btn-sm" type="button" onClick={() => setShowResumePreview(true)}>
                <FileText size={13} /> Resume Analysis
              </button>
            )}
          </div>
        }
      />

      {/* Resume Upload Area */}
      <section
        className={`chatbot-upload-area${isDragging ? " dragging" : ""}`}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onDragOver={(e) => e.preventDefault()}
      >
        <input
          type="file"
          ref={fileInputRef}
          style={{ display: "none" }}
          accept=".txt,.pdf,.doc,.docx,application/pdf,text/plain"
          onChange={(e) => {
            if (e.target.files?.[0]) {
              void handleFileUpload(e.target.files[0]);
            }
          }}
        />
        <div className="upload-content">
          <div className="upload-icon">
            <Upload size={24} />
          </div>
          <div className="upload-text">
            <strong>Upload your resume</strong>
            <span>Drag & drop or click to browse (TXT, PDF, DOCX)</span>
          </div>
          <button
            className="btn btn-primary btn-sm"
            type="button"
            onClick={() => fileInputRef.current?.click()}
          >
            <Paperclip size={14} /> Select File
          </button>
        </div>
        {fileName && (
          <div className="uploaded-file">
            <FileText size={14} />
            <span>{fileName}</span>
            <button
              className="btn-icon mini-danger"
              type="button"
              onClick={() => {
                setFileName("");
                setResumeText("");
                setResumeAnalysis(null);
              }}
              aria-label="Remove file"
            >
              <X size={12} />
            </button>
          </div>
        )}
      </section>

      {resumeAnalysis && !showResumePreview && (
        <div className="resume-quick-stats">
          <StatCard
            title="Authenticity"
            value={`${resumeAnalysis.confidence}%`}
            hint={resumeAnalysis.isReal ? "Real resume detected" : "Needs verification"}
            icon={resumeAnalysis.isReal ? <ShieldCheck size={14} color="#29a878" /> : <Brain size={14} color="#e9a756" />}
            tone={resumeAnalysis.isReal ? "green" : "orange"}
          />
          <StatCard
            title="Skills found"
            value={resumeAnalysis.skills.length}
            hint="Extracted from your resume"
            icon={<Sparkles size={14} />}
          />
          <StatCard
            title="Interview ready"
            value={interviewScore ? `${interviewScore}%` : "-"}
            hint={interviewScore ? `Mock interview score` : `Upload resume & start`}
            icon={<Target size={14} />}
          />
          <button className="btn btn-outline btn-sm" type="button" onClick={() => setShowResumePreview(true)}>
            <FileText size={13} /> View Full Analysis
          </button>
        </div>
      )}

      {/* Chat Interface */}
      <section className="chatbot-chat-container">
        <div className="chatbot-messages">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`chatbot-message ${message.role}`}
            >
              <div className="message-avatar">
                {message.role === "assistant" ? (
                  <span className="avatar ai-avatar">
                    <Bot size={14} />
                  </span>
                ) : (
                  <span className="avatar user-avatar">
                    <User size={14} />
                  </span>
                )}
              </div>
              <div className="message-content">
                <div className="message-text">
                  {message.content.split("\n").map((line, index) => (
                    <span key={index}>
                      {line}
                      <br />
                    </span>
                  ))}
                </div>
                <div className="message-time">{formatTime(message.timestamp)}</div>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="chatbot-message assistant">
              <div className="message-avatar">
                <span className="avatar ai-avatar">
                  <Bot size={14} />
                </span>
              </div>
              <div className="message-content">
                <div className="message-text typing-indicator">
                  <Loader2 className="typing-spinner" size={16} />
                  <span>Thinking...</span>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <form className="chatbot-input-area" onSubmit={handleSendMessage}>
          <div className="input-wrapper">
            <textarea
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder="Type a message... (Try: analyze my resume, mock interview, or ask any question)"
              disabled={isLoading}
              rows={1}
              className="chatbot-input"
            />
            <button
              type="submit"
              className="chatbot-send-btn"
              disabled={isLoading || !inputValue.trim()}
            >
              <Send size={16} />
            </button>
          </div>
          <div className="quick-actions">
            <button
              type="button"
              className="quick-action-btn"
              onClick={() => {
                setInputValue("analyze my resume");
                setTimeout(() => handleSendMessage(), 50);
              }}
              disabled={!resumeText}
            >
              <Brain size={14} /> Analyze Resume
            </button>
            <button
              type="button"
              className="quick-action-btn"
              onClick={() => {
                setInputValue("start mock interview");
                setTimeout(() => handleSendMessage(), 50);
              }}
              disabled={!resumeText}
            >
              <Mic size={14} /> Mock Interview
            </button>
            <button
              type="button"
              className="quick-action-btn"
              onClick={() => {
                setInputValue("what are my strengths?");
                setTimeout(() => handleSendMessage(), 50);
              }}
            >
              <Star size={14} /> My Strengths
            </button>
          </div>
        </form>
      </section>

      {/* Resume Analysis Modal */}
      {showResumePreview && resumeAnalysis && (
        <Modal
          title="Resume Analysis Report"
          description="Detailed breakdown of your resume authenticity and extracted information"
          onClose={() => setShowResumePreview(false)}
        >
          <div className="resume-analysis-modal">
            {/* Authenticity Score */}
            <div className="analysis-score-section">
              <div className="analysis-score-ring">
                <span className="score-value">{resumeAnalysis.confidence}%</span>
                <span className="score-label">Authenticity</span>
              </div>
              <div className="score-status">
                <h3>{resumeAnalysis.isReal ? "✅ Real Resume Detected" : "⚠️ Needs Verification"}</h3>
                <p>
                  Based on content analysis, this resume shows characteristics of a genuine document.
                </p>
              </div>
            </div>

            {/* Reasons */}
            <div className="analysis-section">
              <h4>Analysis Reasons</h4>
              <div className="reasons-list">
                {resumeAnalysis.reasons.map((reason, index) => (
                  <div key={index} className="reason-item">
                    <CheckCircle2 size={14} color="#29a878" />
                    <span>{reason}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Extracted Information */}
            <div className="analysis-section">
              <h4>Extracted Information</h4>
              <div className="extracted-info-grid">
                <div className="info-card">
                  <h5>Skills</h5>
                  <div className="skills-tags">
                    {resumeAnalysis.skills.length > 0 ? (
                      resumeAnalysis.skills.map((skill) => (
                        <span key={skill} className="skill-pill match">
                          {skill}
                        </span>
                      ))
                    ) : (
                      <span className="no-data">No skills detected</span>
                    )}
                  </div>
                </div>
                <div className="info-card">
                  <h5>Education</h5>
                  <p>{resumeAnalysis.education}</p>
                </div>
                <div className="info-card">
                  <h5>Experience</h5>
                  <p>{resumeAnalysis.experience}</p>
                </div>
              </div>
            </div>

            <div className="modal-actions">
              <button className="btn btn-outline btn-sm" type="button" onClick={downloadAnalysis}>
                <Download size={13} /> Download Report
              </button>
              <button
                className="btn btn-primary btn-sm"
                type="button"
                onClick={() => {
                  setShowResumePreview(false);
                  setShowInterviewReport(true);
                }}
              >
                <Target size={13} /> Start Mock Interview
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Mock Interview Modal */}
      {showInterviewReport && (
        <Modal
          title="Mock Interview Setup"
          description="Get ready for your practice interview based on your resume"
          onClose={() => setShowInterviewReport(false)}
        >
          <div className="interview-setup-modal">
            <div className="interview-icon">
              <Mic size={28} />
            </div>
            <h3>Ready for your mock interview?</h3>
            <p>
              Based on your resume, I'll ask you questions related to your skills and experience.
              You'll receive instant feedback on each answer.
            </p>

            <div className="interview-features">
              <div className="feature-item">
                <Check size={16} color="#29a878" />
                <span>5 personalized questions</span>
              </div>
              <div className="feature-item">
                <Clock3 size={16} color="#29a878" />
                <span>Instant feedback on answers</span>
              </div>
              <div className="feature-item">
                <Target size={16} color="#29a878" />
                <span>Final score & recommendations</span>
              </div>
            </div>

            <div className="interview-tips">
              <strong>Tips for a great interview:</strong>
              <ul>
                <li>Use the STAR method (Situation, Task, Action, Result)</li>
                <li>Be specific about your contributions</li>
                <li>Mention technologies and tools you've used</li>
                <li>Highlight outcomes and impact</li>
              </ul>
            </div>

            <div className="modal-actions">
              <button className="btn btn-ghost" type="button" onClick={() => setShowInterviewReport(false)}>
                Cancel
              </button>
              <button
                className="btn btn-primary"
                type="button"
                onClick={() => {
                  setShowInterviewReport(false);
                  setInterviewActive(true);
                  setInputValue("start mock interview");
                  setTimeout(() => handleSendMessage(), 50);
                }}
              >
                <Mic size={14} /> Start Interview
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Interview Complete Report */}
      {interviewScore !== null && interviewScore > 0 && (
        <div className="interview-complete-banner">
          <div className="banner-icon">
            <CheckCircle2 size={18} color="#29a878" />
          </div>
          <div className="banner-content">
            <strong>Mock Interview Complete!</strong>
            <span>Your score: {interviewScore}%</span>
          </div>
          <Link className="btn btn-primary btn-sm" href="/applications">
            View Application Tracker
            <ArrowRight size={12} />
          </Link>
        </div>
      )}
    </AppShell>
  );
}
