"use client";

import { useEffect } from "react";
import Link from "next/link";
import { ArrowLeft, ArrowRight, CheckCircle2, GraduationCap, ShieldCheck } from "lucide-react";
import { BrandLogo } from "@/components/common";
import { useDemo } from "@/lib/demo-store";

export function LogoutPage() {
  const { state, signOut } = useDemo();

  useEffect(() => {
    if (state.role !== null) signOut();
  }, [state.role, signOut]);

  return (
    <main className="logout-page">
      <header className="logout-header"><BrandLogo /><Link className="back-link" href="/"><ArrowLeft size={13} /> Back to home</Link></header>
      <section className="logout-card" aria-labelledby="logout-title">
        <div className="logout-success-icon"><CheckCircle2 size={27} /></div>
        <span className="logout-eyebrow">SESSION ENDED</span>
        <h1 id="logout-title">You’re signed out.</h1>
        <p>Your demo session has ended. Your saved profile and application data stay in this browser so you can pick up where you left off next time.</p>
        <div className="logout-actions">
          <Link className="btn btn-primary" href="/login"><GraduationCap size={15} /> Student sign in <ArrowRight size={14} /></Link>
          <Link className="btn btn-outline" href="/admin/login"><ShieldCheck size={15} /> Recruiter sign in <ArrowRight size={14} /></Link>
        </div>
        <Link className="logout-home-link" href="/">Return to InternMatch AI home <ArrowRight size={13} /></Link>
      </section>
      <footer className="logout-footer">InternMatch AI <span>·</span> Your Skills. Your Potential. Your Opportunity.</footer>
    </main>
  );
}
